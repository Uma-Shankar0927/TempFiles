import process from 'node:process';
import { execute } from './tools.mjs';
import { preBuild } from './pre-build.mjs';

await preBuild(false);

const configuration = process.argv.find((p) => p.startsWith('configuration:'))?.replace('configuration:', '') || 'local';
console.log(`building with configuration: ${configuration}`);
await execute(`ng build --configuration ${configuration}`);

export const safePackageInstalls = {
    '@fusion/ngx-fusion-external': 'postinstall',
    esbuild: 'postinstall',
    sharp: 'install',
    swiftlint: 'postinstall'
};

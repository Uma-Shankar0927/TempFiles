import { npmAuth, npmInstall } from './tools.mjs';

await npmAuth();
await npmInstall('./', true);

import * as tools from './tools.mjs'

await tools.execute('npm run clean', '../');

console.log('removing package-lock.json...')
await tools.removePath('../package-lock.json');

console.log('cleaning node_modules (this can be a long process)...');
await tools.removePath('../node_modules');

console.log('cleaning npm cache (this can be a long process)...');
await tools.execute('npm cache clean --force');


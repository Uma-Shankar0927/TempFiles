import * as tools from './tools.mjs'

console.log('cleaning web client...');
await tools.removePath('.angular');
await tools.removePath('dist');
await tools.removePath('obj');

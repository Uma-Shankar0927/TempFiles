import { Meter, Transformer } from "./types";


export function utilityTypeFilterProperty(meter: Meter) {
    return meter.utility_type.split(',').map(item => item.trim().toLowerCase());
}

export function utilityTypeFilter(utility: string, filterValue: string): boolean {
    // HACK: the kendo grid does some weird formatting with the value...
    const utilityArray = utility.split(',').map(item => item.trim().toLowerCase());
    const filterValueLower = filterValue.toLowerCase();
    return utilityArray.some(item => item === filterValueLower);
}

export function algorithmFilterProperty(meter: Meter): string[] {
    return meter.algorithm.map(item => item.type);
}

export function algorithmFilter(algorithm: string, filterValue: string): boolean {
    // HACK: the kendo grid does some weird formatting with the value...
    const algorithmArray = algorithm.split(',').map(item => item.trim().toLowerCase());
    const filterValueLower = filterValue.toLowerCase();
    return algorithmArray.some(item => item === filterValueLower);
}

export function transformerFilterProperty(transformer: Transformer): string[] {
    // Assuming transformer.status is a comma-separated string
    return transformer.status.split(',').map(item => item.trim().toLowerCase());
}

export function transformerFilter(transformer: string, filterValue: string): boolean {
    // HACK: the kendo grid does some weird formatting with the value...
    const transformerArray = transformer.split(',').map(item => item.trim().toLowerCase());
    const filterValueLower = filterValue.toLowerCase();
    return transformerArray.some(item => item === filterValueLower);
}

export function pcbFilterProperty(transformer: Transformer): string[] {
    // Assuming transformer.pcb is a comma-separated string
    return transformer.pcb.split(',').map(item => item.trim().toLowerCase());
}

export function pcbFilter(transformer: string, filterValue: string): boolean {
    // HACK: the kendo grid does some weird formatting with the value...
    const pcbArray = transformer.split(',').map(item => item.trim().toLowerCase());
    const filterValueLower = filterValue.toLowerCase();
    return pcbArray.some(item => item === filterValueLower);
}
import { Injectable, signal } from '@angular/core';

@Injectable({
    providedIn: 'root'
})
export class SecurityService {
    //TODO: Pull actual role from API
    roleId = signal<number | undefined>(undefined);

    isDistributionOps = signal<boolean>(false);
    isRevenueAssurance = signal<boolean>(false);

    setRoleId(id: number) {
        this.roleId.set(id);
        this.isDistributionOps.set(id === 1);
        this.isRevenueAssurance.set(id === 2);
    }
}

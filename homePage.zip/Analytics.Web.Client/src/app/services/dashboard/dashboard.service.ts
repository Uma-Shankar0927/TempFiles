import { Injectable } from '@angular/core';
import { Card, FilteredCard } from '../../types';

@Injectable({
    providedIn: 'root'
})
export class DashboardService {
    cards: Card[] = [
        {
            id: 1,
            title: 'Total Substations',
            risk: null,
            amount: 24,
            description: 'Across all regions',
            lastUpdated: null,
            viewButton: false,
            distributionOps: true,
            badgeAmount: null,
            case: 'distribution'
        },
        // {
        //     id: 2,
        //     title: 'Current Load',
        //     risk: null,
        //     amount: '67,200 kVA',
        //     description: '75.1% efficiency',
        //     lastUpdated: null,
        //     viewButton: false,
        //     distributionOps: true
        //     badgeAmount: null,
        //     case: null
        // },
        {
            id: 3,
            title: 'Total Transformers',
            risk: null,
            amount: 152,
            description: 'Active monitoring',
            lastUpdated: null,
            viewButton: false,
            distributionOps: true,
            badgeAmount: null,
            case: 'distribution'
        },
        // {
        //     id: 4,
        //     title: 'Rated Capacity',
        //     risk: null,
        //     amount: '89,500kVA',
        //     description: 'Total system capacity',
        //     lastUpdated: null,
        //     viewButton: false,
        //     distributionOps: true,
        //     badgeAmount: null,
        //     case: null
        // },
        {
            id: 5,
            title: 'Total Feeders',
            risk: null,
            amount: 12,
            description: 'Total feeders',
            lastUpdated: null,
            viewButton: false,
            distributionOps: true,
            badgeAmount: null,
            case: 'distribution'
        },
        {
            id: 6,
            title: 'Total Meters',
            risk: null,
            amount: 342,
            description: 'Total meters',
            lastUpdated: null,
            viewButton: false,
            distributionOps: true,
            badgeAmount: null,
            case: 'distribution'
        },
        {
            id: 8,
            title: 'Hot Socket',
            risk: 'critical',
            amount: 15,
            description: 'Temperature above safe threshold',
            lastUpdated: 'Updated 2 mins ago',
            viewButton: true,
            revenueAssurance: true,
            badgeAmount: null,
            case: 'metering'
        },
        {
            id: 9,
            title: 'Double Voltage',
            risk: 'low',
            amount: 3,
            description: 'Voltage at 200% of normal',
            lastUpdated: 'Updated 10 mins ago',
            viewButton: true,
            revenueAssurance: true,
            badgeAmount: null,
            case: 'metering'
        },
        {
            id: 10,
            title: 'Miscellaneous Voltage',
            risk: 'medium',
            amount: 12,
            description: 'Various voltage anomalies',
            lastUpdated: 'Updated 15 mins ago',
            viewButton: true,
            revenueAssurance: true,
            badgeAmount: 6,
            case: 'metering'
        },
        {
            id: 11,
            title: 'Frequent Outages',
            risk: 'high',
            amount: 6,
            description: 'Areas with recurring outages',
            lastUpdated: 'Updated 20 mins ago',
            viewButton: true,
            revenueAssurance: true,
            badgeAmount: 3,
            case: 'metering'
        },

        {
            id: 12,
            title: 'Communicating - No Reads',
            risk: 'medium',
            amount: 18,
            description: 'Communication without data',
            lastUpdated: 'Updated 45 mins ago',
            viewButton: true,
            revenueAssurance: true,
            badgeAmount: 11,
            case: 'metering'
        },
        {
            id: 13,
            title: 'Diagnostic 1',
            risk: 'high',
            amount: 8,
            description: 'No diagnostics in 24 hrs',
            lastUpdated: 'Updated 25 minutes ago',
            viewButton: true,
            revenueAssurance: true,
            badgeAmount: null,
            case: 'metering'
        },
        {
            id: 14,
            title: 'Diagnostic 2',
            risk: 'medium',
            amount: 2,
            description: 'No diagnostics in 24 hrs',
            lastUpdated: 'Updated 25 minutes ago',
            viewButton: true,
            revenueAssurance: true,
            badgeAmount: null,
            case: 'metering'
        },
        {
            id: 15,
            title: 'Zero Electricity Usage',
            risk: 'low',
            amount: 31,
            description: 'No consumption detected',
            lastUpdated: 'Updated 1 hour ago',
            viewButton: true,
            revenueAssurance: true,
            badgeAmount: 4,
            case: 'revenue protection'
        },
        {
            id: 16,
            title: 'Half Voltage',
            risk: 'high',
            amount: 8,
            description: 'Voltage at 50% of normal',
            lastUpdated: 'Updated 3 mins ago',
            viewButton: true,
            revenueAssurance: true,
            badgeAmount: null,
            case: 'revenue protection'
        },
        {
            id: 17,
            title: 'RP Removed Meters',
            risk: 'high',
            amount: 5,
            description: 'Revenue protection removals',
            lastUpdated: 'Updated 1 hour ago',
            viewButton: true,
            revenueAssurance: true,
            badgeAmount: 8,
            case: 'revenue protection'
        },
        {
            id: 18,
            title: 'Reverse Energy',
            risk: 'high',
            amount: 9,
            description: 'Energy flowing in reverse',
            lastUpdated: 'Updated 1 hour ago',
            viewButton: true,
            revenueAssurance: true,
            badgeAmount: null,
            case: 'revenue protection'
        },

        {
            id: 19,
            title: 'Unreachable After Last Gasp',
            risk: 'high',
            amount: 7,
            description: 'No contact after last gasp',
            lastUpdated: 'Updated 15 minutes ago',
            viewButton: true,
            revenueAssurance: true,
            badgeAmount: null,
            case: 'revenue protection'
        },
        {
            id: 20,
            title: 'Load-Side Voltage',
            risk: 'low',
            amount: 1,
            description: 'Voltage issues on load side',
            lastUpdated: 'Updated 5 minutes ago',
            viewButton: true,
            revenueAssurance: true,
            badgeAmount: null,
            case: 'revenue protection'
        },
        {
            id: 7,
            title: 'Error on Service Order',
            risk: null,
            amount: 1,
            description: 'Issues needing review',
            lastUpdated: 'Updated 5 minutes ago',
            viewButton: true,
            revenueAssurance: true,
            badgeAmount: null,
            case: 'revenue protection'
        },
        {
            id: 21,
            title: 'Stuck Load - Electric',
            risk: 'medium',
            amount: 1,
            description: 'Electric load not updating',
            lastUpdated: 'Updated 1 hour ago',
            viewButton: true,
            revenueAssurance: true,
            badgeAmount: 1,
            case: 'customer service'
        },
        {
            id: 22,
            title: 'Stuck Load - Gas',
            risk: 'medium',
            amount: 6,
            description: 'Gas load not updating',
            lastUpdated: 'Updated 25 minutes ago',
            viewButton: true,
            revenueAssurance: true,
            badgeAmount: 3,
            case: 'customer service'
        }
    ];

   filteredCards: FilteredCard[] = [
       {
            id: 1,
            title: 'Immediate',
            description: [
                { summer: 'Summer Loading (April-September) > 140%' },
                { winter: 'Winter Loading (October-March) > 170%' }
            ],
            total: 50,
            revenueAssurance: false,
            distributionOps: true,
            case: 'distribution',
            daily: 10,
            weekly: 50,
            monthly: 200,
            yearly: 2400
       },
       {
            id: 2,
            title: 'Overloaded',
            description: [
                { summer: 'Summer Loading (April-September) > 130%' },
                { winter: 'Winter Loading (October-March) > 160%' }
            ],
            total: 269,
            revenueAssurance: false,
            distributionOps: true,
            case: 'distribution',
            daily: 10,
            weekly: 50,
            monthly: 200,
            yearly: 2400
       },
       {
            id: 3,
            title: 'Watchlist',
            description: [
                { summer: 'Summer Loading (April-September) > 100%' },
                { winter: 'Winter Loading (October-March) > 125%' }
            ],
            total: 435,
            revenueAssurance: false,
            distributionOps: true,
            case: 'distribution',
            daily: 10,
            weekly: 50,
            monthly: 200,
            yearly: 2400
       },
       {
            id: 4,
            title: 'Normal',
            description: [
                { summer: 'Summer Loading (April-September) > 70%' },
                { winter: 'Winter Loading (October-March) > 90%' }
            ],
            total: 12000,
            revenueAssurance: false,
            distributionOps: true,
            case: 'distribution',
            daily: 10,
            weekly: 50,
            monthly: 200,
            yearly: 2400
       },
       {
            id: 5,
            title: 'Underloaded',
            description: [
                { summer: 'Summer Loading (April-September) 0-70%' },
                { winter: 'Winter Loading (October-March) 0-90%' }
            ],
            total: 200,
            revenueAssurance: false,
            distributionOps: true,
            case: 'distribution',
            daily: 10,
            weekly: 50,
            monthly: 200,
            yearly: 2400
       }
   ];
}

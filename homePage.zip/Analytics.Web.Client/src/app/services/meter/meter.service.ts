import { Injectable } from '@angular/core';
import { Meter } from '../../types';

@Injectable({
    providedIn: 'root'
})
export class MeterService {
    meters: Meter[] = [
        {
            meter_number: '0035488785',
            utility_type: 'solar',
            status: 'inactive',
            address: '123 Main St',
            city: 'Lexington',
            zip: '29201',
            account_number: '1234567890',
            account_name: 'John Doe',
            customer_type: 'Residential',
            point_id: '0035488785',
            rating: 1,
            circuit: 7,
            substation_name: 'Airport',
            confidence_score: '70%',
            lead_date: '01/15/2024',
            algorithm: [
                {
                    date: '01/21/2024',
                    type: 'Miscellaneous Voltage'
                },
                {
                    date: '03/13/2024',
                    type: 'Hot Socket'
                }
            ],
            work_order: [
                {
                    id: '1',
                    wo_date: '07/10/2025',
                    wo_time: '10:00 AM',
                    service_point_id: '016186178971E00010001',
                    premise_id: '6186178971',
                    meter_id: '0035488785',
                    account_id: '197401839848',
                    priority: 0.9998,
                    confidence: 0.5,
                    list_name: 'Hot Socket',
                    list_date: '07/10/2025',
                    sent_date: '07/11/2025',
                    wo_status: 'Open',
                    user_id: 'user123',
                    note: [
                        {
                            eid: 'AB12345',
                            text: 'Initial work order created.',
                            timestamp: new Date()
                        }
                    ]
                },
                {
                    id: '1.1',
                    wo_date: '08/05/2025',
                    wo_time: '3:15 PM',
                    service_point_id: '016186178971E00010001',
                    premise_id: '6186178971',
                    meter_id: '0035488785',
                    account_id: '197401839848',
                    priority: 0.9998,
                    confidence: 0.25,
                    list_name: 'Reverse Energy',
                    list_date: '08/12/2025',
                    sent_date: '08/12/2025',
                    wo_status: 'Open',
                    user_id: 'user123',
                    note: [
                        {
                            eid: 'AB12345',
                            text: 'Initial work order created.',
                            timestamp: new Date()
                        }
                    ]
                }
            ]
        },
        {
            meter_number: '0075984568',
            utility_type: 'electric',
            status: 'inactive',
            address: '989 Sky Drive',
            city: 'Irmo',
            zip: '29201',
            account_number: '0987654321',
            account_name: 'Jane Doer',
            customer_type: 'Commercial',
            point_id: '0075984568',
            rating: 5,
            circuit: 7,
            substation_name: 'Congaree Vista',
            confidence_score: '80%',
            lead_date: '01/15/2024',
            algorithm: [
                {
                    date: '04/28/2025',
                    type: 'Double Voltage'
                }
            ],
            work_order: [
                {
                    id: '2',
                    wo_date: '07/27/2025',
                    wo_time: '1:00 PM',
                    service_point_id: '016186178971E00010001',
                    premise_id: '5685489578',
                    meter_id: '0075984568',
                    account_id: '898598759825',
                    priority: 0.8885,
                    confidence: 0.75,
                    list_name: 'Double Voltage',
                    list_date: '08/01/2025',
                    sent_date: '08/01/2025',
                    wo_status: 'Closed',
                    user_id: 'user123',
                    note: [
                        {
                            eid: 'AB12345',
                            text: 'Initial work order created.',
                            timestamp: new Date()
                        }
                    ]
                }
            ]
        },
        {
            meter_number: '0018188080',
            utility_type: 'gas',
            status: 'active',
            address: '125 Main St',
            city: 'Lexington',
            zip: '29201',
            account_number: '1234567890',
            account_name: 'John Doe',
            customer_type: 'Residential',
            point_id: '0035488785',
            rating: 5,
            circuit: 7,
            substation_name: 'Brookwood',
            confidence_score: '70%',
            lead_date: '01/15/2024',
            algorithm: [],
            work_order: []
        },
        {
            meter_number: '0029876546',
            utility_type: 'solar',
            status: 'active',
            address: '126 Solar St',
            city: 'West Columbia',
            zip: '29201',
            account_number: '1234567890',
            account_name: 'John Doe',
            customer_type: 'Residential',
            point_id: '0035488785',
            rating: 5,
            circuit: 7,
            substation_name: 'Brookwood',
            confidence_score: '50%',
            lead_date: '01/15/2024',
            algorithm: [
                {
                    date: '07/14/2024',
                    type: 'Frequent Outages'
                },
                {
                    date: '01/01/2023',
                    type: 'Targeted No Meters'
                }
            ],
            work_order: [
                {
                    id: '4',
                    wo_date: '07/10/2025',
                    wo_time: '10:00 AM',
                    service_point_id: '016186178971E00010001',
                    premise_id: '6186178971',
                    meter_id: '0035488785',
                    account_id: '197401839848',
                    priority: 0.9998,
                    confidence: 0.5,
                    list_name: 'Hot Socket',
                    list_date: '07/10/2025',
                    sent_date: '07/11/2025',
                    wo_status: 'Open',
                    user_id: 'user123',
                    note: [
                        {
                            eid: 'AB12345',
                            text: 'Initial work order created.',
                            timestamp: new Date()
                        }
                    ]
                }
            ]
        },
        {
            meter_number: '0036548975',
            utility_type: 'gas',
            status: 'active',
            address: '127 Skye St',
            city: 'Columbia',
            zip: '29201',
            account_number: '1234567890',
            account_name: 'John Doe',
            customer_type: 'Commercial',
            point_id: '0035488785',
            rating: 5,
            circuit: 7,
            substation_name: 'Columbia Industrial Park',
            confidence_score: '20%',
            lead_date: '01/15/2024',
            algorithm: [
                {
                    date: '06/20/2025',
                    type: 'Communicating with No Reads'
                }
            ],
            work_order: [
                {
                    id: '5',
                    wo_date: '07/10/2025',
                    wo_time: '10:00 AM',
                    service_point_id: '016186178971E00010001',
                    premise_id: '6186178971',
                    meter_id: '0035488785',
                    account_id: '197401839848',
                    priority: 0.9998,
                    confidence: 0.5,
                    list_name: 'Hot Socket',
                    list_date: '07/10/2025',
                    sent_date: '07/11/2025',
                    wo_status: 'Open',
                    user_id: 'user123',
                    note: [
                        {
                            eid: 'AB12345',
                            text: 'Initial work order created.',
                            timestamp: new Date()
                        }
                    ]
                }
            ]
        },

        {
            meter_number: '0022582145',
            utility_type: 'electric',
            status: 'active',
            address: '128 Main St',
            city: 'Columbia',
            zip: '29201',
            account_number: '1234567890',
            account_name: 'John Doe',
            customer_type: 'Residential',
            point_id: '0035488785',
            rating: 5,
            circuit: 7,
            substation_name: 'Columbia Industrial Park',
            confidence_score: '30%',
            lead_date: '01/15/2024',
            algorithm: [
                {
                    date: '12/30/2024',
                    type: 'Zero Electricity Usage'
                }
            ],
            work_order: [
                {
                    id: '6',
                    wo_date: '07/10/2025',
                    wo_time: '10:00 AM',
                    service_point_id: '016186178971E00010001',
                    premise_id: '6186178971',
                    meter_id: '0035488785',
                    account_id: '197401839848',
                    priority: 0.9998,
                    confidence: 0.5,
                    list_name: 'Hot Socket',
                    list_date: '07/10/2025',
                    sent_date: '07/11/2025',
                    wo_status: 'Open',
                    user_id: 'user123',
                    note: [
                        {
                            eid: 'AB12345',
                            text: 'Initial work order created.',
                            timestamp: new Date()
                        }
                    ]
                }
            ]
        },
        {
            meter_number: '0052545452',
            utility_type: 'electric',
            status: 'inactive',
            address: '123 Main St',
            city: 'Cayce',
            zip: '29201',
            account_number: '1234567890',
            account_name: 'John Doe',
            customer_type: 'Commercial',
            point_id: '0035488785',
            rating: 5,
            circuit: 7,
            substation_name: 'Airport',
            confidence_score: '60%',
            lead_date: '01/15/2024',
            algorithm: [
                {
                    date: '02/09/2024',
                    type: 'RP Removed Meters'
                }
            ],
            work_order: [
                {
                    id: '7',
                    wo_date: '07/10/2025',
                    wo_time: '10:00 AM',
                    service_point_id: '016186178971E00010001',
                    premise_id: '6186178971',
                    meter_id: '0035488785',
                    account_id: '197401839848',
                    priority: 0.9998,
                    confidence: 0.5,
                    list_name: 'Hot Socket',
                    list_date: '07/10/2025',
                    sent_date: '07/11/2025',
                    wo_status: 'Open',
                    user_id: 'user123',
                    note: [
                        {
                            eid: 'AB12345',
                            text: 'Initial work order created.',
                            timestamp: new Date()
                        }
                    ]
                }
            ]
        },
        {
            meter_number: '0032156844',
            utility_type: 'gas',
            status: 'active',
            address: '123 Solar St',
            city: 'Columbia',
            zip: '29201',
            account_number: '1234567890',
            account_name: 'John Doe',
            customer_type: 'Residential',
            point_id: '0035488785',
            rating: 5,
            circuit: 7,
            substation_name: 'Dixiana',
            confidence_score: '90%',
            lead_date: '01/15/2024',
            algorithm: [
                {
                    date: '01/01/2023',
                    type: 'Reverse Energy'
                },
                {
                    date: '11/18/2024',
                    type: 'Hot Socket'
                },
                {
                    date: '06/14/2025',
                    type: 'Double Voltage'
                }
            ],
            work_order: [
                {
                    id: '8',
                    wo_date: '07/10/2025',
                    wo_time: '10:00 AM',
                    service_point_id: '016186178971E00010001',
                    premise_id: '6186178971',
                    meter_id: '0035488785',
                    account_id: '197401839848',
                    priority: 0.9998,
                    confidence: 0.5,
                    list_name: 'Hot Socket',
                    list_date: '07/10/2025',
                    sent_date: '07/11/2025',
                    wo_status: 'Open',
                    user_id: 'user123',
                    note: [
                        {
                            eid: 'AB12345',
                            text: 'Initial work order created.',
                            timestamp: new Date()
                        }
                    ]
                }
            ]
        }
    ];
}

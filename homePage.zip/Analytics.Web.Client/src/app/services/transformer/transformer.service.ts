import { Injectable } from '@angular/core';
import { Transformer, Circuit } from '../../types';

@Injectable({
    providedIn: 'root'
})
export class TransformerService {
    circuits: Circuit[] = [];

    transformers: Transformer[] = [
        {
            status: 'normal',
            point_id: '0030043354',
            pole_id: '0043354',
            rating: 125,
            pcb: 'Contains PCBs',
            active_meter_count: ['0035488785', '0075984568', '0018188080'],
            substation_name: 'Brookwood',
            circuit_id: '14042',
            crew_quarter: 'Columbia Metro',
            statusInfo: {
                date: 'Aug 24, 2025',
                duration: 'daily',
                loadPercent: '30%'
            },
            phase: ['A', 'B']
        },
        {
            status: 'underloaded',
            point_id: '0030436435',
            pole_id: '0436435',
            rating: 150,
            pcb: 'Contains PCBs Installed',
            active_meter_count: [],
            substation_name: 'Columbia Industrial Park',
            circuit_id: '78602',
            crew_quarter: 'Columbia Metro',
            statusInfo: {
                date: 'Aug 24, 2025',
                duration: 'weekly',
                loadPercent: '30%'
            },
            phase: ['B', 'C']
        },
        {
            status: 'watchlist',
            point_id: '003C053901',
            pole_id: 'C053901',
            rating: 75,
            pcb: 'Unknown',
            active_meter_count: ['0035488785'],
            substation_name: 'Kendrick',
            circuit_id: '18322',
            crew_quarter: 'Columbia Metro',
            statusInfo: {
                date: 'Aug 24, 2025',
                duration: 'monthly',
                loadPercent: '30%'
            },
            phase: ['A', 'C']
        },
        {
            status: 'overloaded',
            point_id: '003PD03457',
            pole_id: 'PD03457',
            rating: 150,
            pcb: 'Unknown Installed',
            active_meter_count: ['0075984568', '0018188080'],
            substation_name: 'Dixiana',
            circuit_id: '16312',
            crew_quarter: 'Columbia Metro',
            statusInfo: {
                date: 'Aug 24, 2025',
                duration: 'yearly',
                loadPercent: '30%'
            },
            phase: ['A', 'B', 'C']
        },
        {
            status: 'immediate',
            point_id: '003PD55859',
            pole_id: 'PD55859',
            rating: 500,
            pcb: 'Status Unknown',
            active_meter_count: [
                '0035488785',
                '0075984568',
                '0018188080',
                '0029876546',
                '0036548975',
                '0052545452',
                '0032156844'
            ],
            substation_name: 'Congaree Vista',
            circuit_id: '20432',
            crew_quarter: 'Columbia Metro',
            statusInfo: {
                date: 'Aug 24, 2025',
                duration: 'daily',
                loadPercent: '30%'
            },
            phase: ['A', 'B', 'C']
        },
        {
            status: 'normal',
            point_id: '0040471721',
            pole_id: '0471721',
            rating: 300,
            pcb: 'Contains PCBs',
            active_meter_count: ['0035488785', '0075984568', '0018188080'],
            substation_name: 'Congaree Creek',
            circuit_id: '23912',
            crew_quarter: 'Columbia Metro',
            statusInfo: {
                date: 'Aug 24, 2025',
                duration: 'weekly',
                loadPercent: '30%'
            },
            phase: ['B']
        },
        {
            status: 'watchlist',
            point_id: '003PD59481',
            pole_id: 'PD59481',
            rating: 225,
            pcb: 'Contains PCBs Installed',
            active_meter_count: ['0035488785', '0075984568', '0018188080'],
            substation_name: 'Airport',
            circuit_id: '74912',
            crew_quarter: 'Columbia Metro',
            statusInfo: {
                date: 'Aug 24, 2025',
                duration: 'monthly',
                loadPercent: '30%'
            },
            phase: ['C']
        },
        {
            status: 'underloaded',
            point_id: '0030027688',
            pole_id: '0027688',
            rating: 150,
            pcb: 'Status Unknown',
            active_meter_count: ['0035488785', '0075984568', '0018188080'],
            substation_name: 'Victory Gardens',
            circuit_id: '23611',
            crew_quarter: 'Columbia Metro',
            statusInfo: {
                date: 'Aug 24, 2025',
                duration: 'yearly',
                loadPercent: '30%'
            },
            phase: ['A']
        }
    ];
}

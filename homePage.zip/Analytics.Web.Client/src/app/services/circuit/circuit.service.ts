import { Injectable } from '@angular/core';
import { Circuit } from '../../types';

@Injectable({
    providedIn: 'root'
})
export class CircuitService {
    circuits: Circuit[] = [
        {
            circuit_id: '0030043354',
            line_transformer_count: 5,
            active_meter_count: 7,
            substation_name: 'Columbia Industrial Park',
            bank_size: 100,
            voltage: '12kV',
            phase: ['A', 'B', 'C'],
            rating: 200,
            install_date: '02/15/2018',

            child_points: [
                {
                    meter_number: '0035488785'
                },
                {
                    meter_number: '0075984568'
                }
            ],

            algorithm: [
                {
                    date: '01/21/2024',
                    type: 'Miscellaneous Voltage'
                },
                {
                    date: '03/13/2024',
                    type: 'Hot Socket'
                }
            ],
            transformer: [
                {
                    status: 'Active',
                    point_id: '0030043354',
                    pole_id: '0030043354',
                    rating: 100,
                    pcb: 'PCB1',
                    active_meter_count: ['Meter1', 'Meter2'],
                    substation_name: 'Substation1',
                    circuit_id: 'Circuit1',
                    crew_quarter: 'Columbia Metro',
                    statusInfo: {
                        date: '01/21/2024',
                        duration: '2 hours',
                        loadPercent: '75%'
                    },
                    phase: ['A', 'B', 'C']
                }
            ]
        },
        {
            circuit_id: '0030058546',
            line_transformer_count: 3,
            active_meter_count: 4,
            substation_name: 'Brookwood',
            bank_size: 80,
            voltage: '20kV',
            phase: ['A', 'B', 'C'],
            rating: 200,
            install_date: '02/15/2018',

            child_points: [
                {
                    meter_number: 'ChildMeter1'
                },
                {
                    meter_number: 'ChildMeter2'
                }
            ],

            algorithm: [
                {
                    date: '01/21/2024',
                    type: 'Miscellaneous Voltage'
                },
                {
                    date: '03/13/2024',
                    type: 'Hot Socket'
                }
            ],
            transformer: [
                {
                    status: 'Active',
                    point_id: '0030043354',
                    pole_id: '0030043354',
                    rating: 100,
                    pcb: 'PCB1',
                    active_meter_count: ['Meter1', 'Meter2'],
                    substation_name: 'Substation1',
                    circuit_id: 'Circuit1',
                    crew_quarter: 'Columbia Metro',
                    statusInfo: {
                        date: '01/21/2024',
                        duration: '2 hours',
                        loadPercent: '75%'
                    },
                    phase: ['A', 'B', 'C']
                }
            ]
        },
        {
            circuit_id: '0045256589',
            line_transformer_count: 3,
            active_meter_count: 4,
            substation_name: 'Airport',
            bank_size: 50,
            voltage: '18kV',
            phase: ['A', 'B', 'C'],
            rating: 150,
            install_date: '02/15/2018',

            child_points: [
                {
                    meter_number: 'ChildMeter1'
                },
                {
                    meter_number: 'ChildMeter2'
                }
            ],

            algorithm: [
                {
                    date: '01/21/2024',
                    type: 'Miscellaneous Voltage'
                },
                {
                    date: '03/13/2024',
                    type: 'Hot Socket'
                }
            ],
            transformer: [
                {
                    status: 'Active',
                    point_id: '0030043354',
                    pole_id: '0030043354',
                    rating: 100,
                    pcb: 'PCB1',
                    active_meter_count: ['Meter1', 'Meter2'],
                    substation_name: 'Substation1',
                    circuit_id: 'Circuit1',
                    crew_quarter: 'Columbia Metro',
                    statusInfo: {
                        date: '01/21/2024',
                        duration: '2 hours',
                        loadPercent: '75%'
                    },
                    phase: ['A', 'B', 'C']
                }
            ]
        },
        {
            circuit_id: '0015005197',
            line_transformer_count: 3,
            active_meter_count: 4,
            substation_name: 'Congaree Vista',
            bank_size: 80,
            voltage: '30kV',
            phase: ['A', 'B', 'C'],
            rating: 150,
            install_date: '02/15/2018',

            child_points: [
                {
                    meter_number: 'ChildMeter1'
                },
                {
                    meter_number: 'ChildMeter2'
                }
            ],

            algorithm: [
                {
                    date: '01/21/2024',
                    type: 'Miscellaneous Voltage'
                },
                {
                    date: '03/13/2024',
                    type: 'Hot Socket'
                }
            ],
            transformer: [
                {
                    status: 'Active',
                    point_id: '0030043354',
                    pole_id: '0030043354',
                    rating: 100,
                    pcb: 'PCB1',
                    active_meter_count: ['Meter1', 'Meter2'],
                    substation_name: 'Substation1',
                    circuit_id: 'Circuit1',
                    crew_quarter: 'Columbia Metro',
                    statusInfo: {
                        date: '01/21/2024',
                        duration: '2 hours',
                        loadPercent: '75%'
                    },
                    phase: ['A', 'B', 'C']
                }
            ]
        }
    ];
}

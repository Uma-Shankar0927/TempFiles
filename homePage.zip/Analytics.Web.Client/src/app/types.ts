export interface MyEntity {
    id: string | null;
    name: string | null;
    description: string | null;
}

export interface Card {
    id: number;
    title: string;
    risk: 'low' | 'medium' | 'high' | 'critical' | null;
    amount: string | number;
    description: string;
    lastUpdated: string | null;
    viewButton: boolean;
    revenueAssurance?: boolean;
    distributionOps?: boolean;
    badgeAmount?: number | null;
    case: 'customer service' | 'metering' | 'revenue protection' | 'distribution';
}

export interface FilteredCard {
    id: number;
    title: string;
    description: [{ summer: string }, { winter: string }];
    total: string | number;
    revenueAssurance?: boolean;
    distributionOps?: boolean;
    case: 'distribution';
    daily: number;
    weekly: number;
    monthly: number;
    yearly: number;
}

export interface Meter {
    meter_number: string | number;
    utility_type: string;
    status: string;
    address: string;
    city: string;
    zip: string;
    account_number: string;
    account_name: string;
    customer_type: string;
    point_id: string;
    rating: number;
    circuit: number;
    substation_name: string;
    confidence_score: string;
    lead_date: string;
    algorithm: Algorithm[];
    work_order: WorkOrder[];
}

export interface Transformer {
    status: string;
    point_id: string;
    pole_id: string;
    rating: number;
    pcb: string;
    active_meter_count: string[];
    substation_name: string;
    circuit_id: string;
    crew_quarter: string;
    statusInfo: {
        date: string;
        duration: string;
        loadPercent: string;
    };
    phase: string[];
}

export interface Circuit {
    circuit_id: string;
    line_transformer_count: number;
    active_meter_count: number;
    substation_name: string;
    bank_size: number;
    voltage: string;
    phase: string[];
    rating: number;
    install_date: string;
    child_points: ChildPoint[];
    algorithm?: Algorithm[];
    transformer?: Transformer[];
}

export interface Algorithm {
    date: string;
    type: string;
}

export interface Note {
    eid: string;
    text: string;
    timestamp: Date;
}

export interface WorkOrder {
    id: string;
    wo_date: string;
    wo_time: string;
    service_point_id: string;
    premise_id: string;
    meter_id: string;
    account_id: string;
    priority: number;
    confidence: number;
    list_name: string;
    list_date: string;
    sent_date: string;
    wo_status: string;
    user_id: string;
    note: Note[];
}

export interface ChildPoint {
    meter_number: string | number;
}

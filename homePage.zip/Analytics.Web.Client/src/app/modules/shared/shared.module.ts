import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { NgxFusionModule } from '@fusion/ngx-fusion';

@NgModule({
    imports: [CommonModule, FormsModule, NgxFusionModule, ReactiveFormsModule, RouterModule],
    exports: [CommonModule, FormsModule, NgxFusionModule, ReactiveFormsModule, RouterModule]
})
export class SharedModule {}

import { CommonModule } from '@angular/common';
import { Component, effect, inject, OnDestroy, viewChild } from '@angular/core';
import {
    FUSION_CARD,
    FUSION_GRID_CONTAINER,
    FusionButtonComponent,
    FusionDialogComponent,
    FusionGridCellComponent,
    FusionGridContainerComponent,
    FusionGridRowComponent,
    FusionPageBaseComponent
} from '@fusion/ngx-fusion';
import { SharedModule } from '../../modules/shared/shared.module';
import { DashboardService } from '../../services/dashboard/dashboard.service';
import { SecurityService } from '../../services/security/security.service';
import { Card, FilteredCard } from '../../types';
import { RouterModule } from '@angular/router';

@Component({
    imports: [
        FUSION_GRID_CONTAINER,
        FusionGridCellComponent,
        FusionGridRowComponent,
        FusionGridContainerComponent,
        CommonModule,
        FUSION_CARD,
        FusionButtonComponent,
        SharedModule,
        RouterModule
    ],
    selector: 'app-dashboard',
    standalone: true,
    templateUrl: './dashboard.component.html',
    styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent extends FusionPageBaseComponent implements OnDestroy {
    readonly securityService = inject(SecurityService);

  private readonly dashboardService = inject(DashboardService);

componentDialog = viewChild.required('componentDialog', { read: FusionDialogComponent });
    
chartColors: string[] = [
  "var(--kendo-color-primary)",
  "var(--kendo-color-success)",
  "var(--kendo-color-warning)",
  "#fc9700ff",
  "var(--kendo-color-error)"
];

transformerStatusColors: string[] = this.chartColors;

filteredCards: FilteredCard[] = this.dashboardService.filteredCards;

cards: Card[] = this.dashboardService.cards;
card: Card[] = [];

metering: Card[] = this.cards.filter((card) => card.case === 'metering' && card.revenueAssurance === this.securityService.isRevenueAssurance()).slice().sort((a, b) => a.title.localeCompare(b.title));
revenueProtection: Card[] = this.cards.filter((card) => card.case === 'revenue protection' && card.revenueAssurance === this.securityService.isRevenueAssurance()).slice().sort((a, b) => a.title.localeCompare(b.title));
customerService: Card[] = this.cards.filter((card) => card.case === 'customer service' && card.revenueAssurance === this.securityService.isRevenueAssurance()).slice().sort((a, b) => a.title.localeCompare(b.title));
distribution: Card[] = this.cards.filter((card) => card.case === 'distribution' && card.distributionOps === this.securityService.isDistributionOps()).slice().sort((a, b) => a.title.localeCompare(b.title));

    private _roleChangeEffect = effect(() => {
        const isRevenueAssurance = this.securityService.isRevenueAssurance();
    const isDistributionOps = this.securityService.isDistributionOps();

  this.metering = this.cards.filter((card) => card.case === 'metering' && card.revenueAssurance === isRevenueAssurance).slice().sort((a, b) => a.title.localeCompare(b.title));
  this.revenueProtection = this.cards.filter((card) => card.case === 'revenue protection' && card.revenueAssurance === isRevenueAssurance).slice().sort((a, b) => a.title.localeCompare(b.title));
  this.customerService = this.cards.filter((card) => card.case === 'customer service' && card.revenueAssurance === isRevenueAssurance).slice().sort((a, b) => a.title.localeCompare(b.title));
  this.distribution = this.cards.filter((card) => card.case === 'distribution' && card.distributionOps === isDistributionOps).slice().sort((a, b) => a.title.localeCompare(b.title));
});

transformerFilterByOptions = [
    {id: 1, name: 'Crew Quarter'},
    {id: 2, name: 'Substation'},
    {id: 3, name: 'Circuit'},
]
transformerFilterByValue = this.transformerFilterByOptions[0].id;

crewQuarterOptions = [
    {id: 1, name: 'Columbia Metro'},
    {id: 2, name: 'Charleston'},
    {id: 3, name: 'Greenville'},
]
crewQuarterValue = this.crewQuarterOptions[0].id;

substationOptions = [
    {id: 1, name: 'Substation 1'},
    {id: 2, name: 'Substation 2'},
    {id: 3, name: 'Substation 3'},
]
substationValue = this.substationOptions[0].id;

circuitOptions = [
    {id: 1, name: 'circuit 1'},
    {id: 2, name: 'circuit 2'},
    {id: 3, name: 'circuit 3'},
]
circuitValue = this.circuitOptions[0].id;

durationOptions: { id: number; durationId: string }[] = [
        { id: 1, durationId: 'All' },
        { id: 2, durationId: 'Daily' },
        { id: 3, durationId: 'Weekly' },
        { id: 4, durationId: 'Monthly' },
        { id: 5, durationId: 'Yearly' }
    ];
durationValue = this.durationOptions[0].durationId;

algorithmDateOptions = [
    {id: 1, name: 'Today'},
    {id: 2, name: 'Last 7 Days'},
    {id: 3, name: 'Last 30 Days'},
    {id: 4, name: 'Last 60 Days'},
    {id: 5, name: 'Last 90 Days'},
]

algorithmDateValue = this.algorithmDateOptions[0].id;

revenueProtectionDateOptions = [
    {id: 1, name: 'Today'},
    {id: 2, name: 'Last 7 Days'},
    {id: 3, name: 'Last 30 Days'},
    {id: 4, name: 'Last 60 Days'},
    {id: 5, name: 'Last 90 Days'},
]

revenueProtectionDateValue = this.revenueProtectionDateOptions[0].id;

customerServiceDateOptions = [
    {id: 1, name: 'Today'},
    {id: 2, name: 'Last 7 Days'},
    {id: 3, name: 'Last 30 Days'},
    {id: 4, name: 'Last 60 Days'},
    {id: 5, name: 'Last 90 Days'},
]

customerServiceDateValue = this.customerServiceDateOptions[0].id;

// sets the cell background color for the statuses
    public codeColor(classification: string): string {
        let color;

        if (classification === 'Underloaded') {
            color = 'var(--kendo-color-primary)' as string;
        } else if (classification === 'Normal') {
            color = 'var(--kendo-color-success)' as string;
        } else if (classification === 'Watchlist') {
            color = 'var(--kendo-color-warning)' as string;
        } else if (classification === 'Overloaded') {
            color = '#fc9700ff' as string;
        } else color = 'var(--kendo-color-error)' as string;

        return color;
    }

  /**
   * Reuses the same status->color mapping as `codeColor()` for the Distribution filtered cards.
   * This is intended for binding to header background colors.
   */
  public filteredCardHeaderBackground(title: string | null | undefined): string {
    return this.codeColor((title ?? '').trim());
  }

  /**
   * Ensures readable text on light backgrounds (notably Watchlist/yellow).
   */
  public filteredCardHeaderTextColor(title: string | null | undefined): string {
    const normalized = (title ?? '').trim().toLowerCase();
    if (normalized === 'watchlist') return 'var(--kendo-color-on-warning, #1a1a1a)';
    return '#fff';
  }

readonly classificationGridData = [
    {
      code: 'Blue',
      classification: 'Underloaded',
      summerLoading: '0-70%',
      winterLoading: '0-90%',
      daily: 'N/A',
      weekly: 'N/A',
      monthly: 'N/A',
      yearly: 'N/A'
    },
    {
      code: 'Green',
      classification: 'Normal',
      summerLoading: '>70%',
      winterLoading: '>90%',
      daily: 'N/A',
      weekly: 'N/A',
      monthly: 'N/A',
      yearly: 'N/A'

    },
    {
      code: 'Yellow',
      classification: 'Watchlist',
      summerLoading: '>100%',
      winterLoading: '>125%',
      daily: '>4 hours',
      weekly: '>20 hours',
      monthly: '>30 hours',
      yearly: '>90 hours'

    },
    {
      code: 'Orange',
      classification: 'Overloaded',
      summerLoading: '>130%',
      winterLoading: '>160%',
      daily: '>4 hours',
      weekly: '>5 hours',
      monthly: '>12 hours',
      yearly: '>48 hours'
      ,
    },
    {
      code: 'Red',
      classification: 'Immediate',
      summerLoading: '>140%',
      winterLoading: '>170%',
      daily: '>1 hour',
      weekly: '>4 hours',
      monthly: '>8 hours',
      yearly: '>24 hours'
    }
  ];


// Transformer Chart Data
transformerData = [
    { category: "Underloaded", value: '200', color: this.transformerStatusColors[0] },
    { category: "Normal", value: '12000', color: this.transformerStatusColors[1] },
    { category: "Watchlist", value: '435', color: this.transformerStatusColors[2] },
    { category: "Overloaded", value: '269', color: this.transformerStatusColors[3] },
    { category: "Immediate", value: '50', color: this.transformerStatusColors[4] },
  ];
// End Transformer Chart Data

// Metering Chart Data
algorithmData = [
    { category: "Hot Socket", value: '3'  },
    { category: "Double Voltage", value: '1'  },
    { category: "Miscellaneous Voltage", value: '5'  },
    { category: "Frequent Outages", value: '4'  },
    { category: "Communicating No Reads", value: '6' },
    { category: "Diagnostic 1", value: '2' },
    { category: "Diagnostic 2", value: '3' },
  ];
// End Metering Chart Data

// Revenue Protection Chart Data
revenueProtectionData = [
    { category: "Zero Electricity Usage", value: '31'  },
    { category: "Half Voltage", value: '8'  },
    { category: "RP Removed Meters", value: '13'  },
    { category: "Reverse Energy", value: '9'  },
    { category: "Unreachable After Last Gasp", value: '7'  },
    { category: "Load-Side Voltage", value: '1'  },
    { category: "Error on Service Order", value: '2'  },
  ];
// End Revenue Protection Chart Data

// Customer Service Chart Data
customerServiceData = [
    { category: "Stuck Load - Electric", value: '2'  },
    { category: "Stuck Load - Gas", value: '9'  }
  ];
// End Customer Service Chart Data

get filteredDistributionCards(): FilteredCard[] {
  // NOTE: these are the *filtered* transformer status cards (FilteredCard), not the standard dashboard cards (Card).
  const isDistributionOps = this.securityService.isDistributionOps();

  return this.filteredCards
    .filter(c => c.case === 'distribution' && c.distributionOps === isDistributionOps)
    .slice()
  .sort((a, b) => a.id - b.id);
}

    override ngOnDestroy(): void {
        super.ngOnDestroy();
        this._roleChangeEffect.destroy();
    }

// Dialog (Modal)

    componentDialogRejected(): void {
        this.fusion.message.globalMessage('Rejected');
        this.componentDialog().close('Rejected');
    }

}

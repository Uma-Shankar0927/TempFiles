import { CommonModule } from '@angular/common';
import {
    FusionGridCellComponent,
    FusionGridContainerComponent,
    FusionGridRowComponent,
    FusionPageBaseComponent,
   
} from '@fusion/ngx-fusion';
import { Component, OnInit } from '@angular/core';
import { FUSION_GRID_CONTAINER } from '@fusion/ngx-fusion';
import { SharedModule } from '../../modules/shared/shared.module';


@Component({
    imports: [
        FUSION_GRID_CONTAINER,
        FusionGridCellComponent,
        FusionGridRowComponent,
        FusionGridContainerComponent,
        CommonModule,
        SharedModule
    ],
    selector: 'app-admin',
    standalone: true,
    templateUrl: './admin.component.html',
    styleUrls: ['./admin.component.scss']
})
export class AdminComponent extends FusionPageBaseComponent implements OnInit {
   coefficientValue?: number;
    coefficientStep = 0.1;

useCaseOptions: { id: number; name: string }[] = [
    {id: 1, name: 'Communicating - No Results'},
    {id: 2, name: 'Diagnostic 1'},
    {id: 3, name: 'Diagnostic 2'},
    {id: 4, name: 'Double Voltage'},
    {id: 5, name: 'Frequent Outages'},
    {id: 6, name: 'Hot Socket'},
    {id: 7, name: 'Miscellaneous Voltage'},
    {id: 8, name: 'Error on Service Order'},
    {id: 9, name: 'Half Voltage'},
    {id: 10, name: 'Load-Side Voltage'},
    {id: 11, name: 'Reverse Energy'},
    {id: 12, name: 'RP Removed Meters'},
    {id: 13, name: 'Unreachable After Last Gasp'},
    {id: 14, name: 'Zero Electricity Usage'},
    {id: 15, name: 'Stuck Load - Electric'},
    {id: 16, name: 'Stuck Load - Gas'},
]
useCaseValue = this.useCaseOptions[0]; // Default to the first option
selectedOption = this.useCaseValue.name;

  onUseCaseChange(newValue: { id: number; name: string }): void {
    this.selectedOption = newValue.name;
  }
tempThresholdValue?: number;
evaluationValue?: number;
maxValidTempValue?: number;
minValidTempValue?: number;
percentileThresholdValue?: number;
}

import { CommonModule } from '@angular/common';
import { Component, inject, OnInit } from '@angular/core';
import { SharedModule } from '../../modules/shared/shared.module';
import { FusionPageBaseComponent } from '@fusion/ngx-fusion';
import { CircuitService } from '../../services/circuit/circuit.service';
import { TransformerService } from '../../services/transformer/transformer.service';
import { MeterService } from '../../services/meter/meter.service';
import { Circuit, Note, Transformer, Meter } from '../../types';
import { Series, ValueAxis } from '@fusion/ngx-fusion/node_modules/@progress/kendo-angular-charts';
import { ActivatedRoute } from '@angular/router';

@Component({
    imports: [CommonModule, SharedModule],
    selector: 'app-circuit-details',
    standalone: true,
    templateUrl: './circuit-details.component.html',
    styleUrls: ['./circuit-details.component.scss']
})
export class CircuitDetailsComponent extends FusionPageBaseComponent implements OnInit {
    circuitId: string | null = null;
    dateRangeValue?: { start: Date; end: Date };

    route = inject(ActivatedRoute);
    override ngOnInit(): void {
        const circuitId = this.route.snapshot.paramMap.get('circuitId');
        this.circuitId = circuitId;
        this.circuit = this.circuits.find((c) => c.circuit_id === this.circuitId);
    }
    circuit?: Circuit;
    circuitService = inject(CircuitService);
    circuits: Circuit[] = this.circuitService.circuits;

    transformerService = inject(TransformerService);
    transformers: Transformer[] = this.transformerService.transformers;

    notes: Note[] = [];

    // A variable to hold the new note text from the form
    newNoteText?: string = '';

    // Method to push a new note to the list
    addNote(): void {
        if (this.newNoteText?.trim() !== '') {
            this.notes.push({
                eid: this.generateRandomEID(),
                text: this.newNoteText ?? '',
                timestamp: new Date()
            });
            // Clear the input field after adding the note
            this.newNoteText = '';
        }
    }

    // Generate Random EID
    generateRandomEID(): string {
        const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        const numbers = '0123456789';
        let eid = '';

        // Two Random Capital Letters
        for (let i = 0; i < 2; i++) {
            eid += letters.charAt(Math.floor(Math.random() * letters.length));
        }
        // Five Random Numbers
        for (let i = 0; i < 5; i++) {
            eid += numbers.charAt(Math.floor(Math.random() * numbers.length));
        }
        return eid;
    }

    // Show/Hide Map
    isHidden = true; // Initial state: hidden

    toggleVisibility() {
        this.isHidden = !this.isHidden; // Toggle the boolean value
    }

    meter?: Meter;
    meterService = inject(MeterService);
    meters = this.meterService.meters;

    timeOptions: TimeBasis[] = [
        {
            id: 1,
            time: '15min'
        },
        {
            id: 2,
            time: 'Hourly'
        },
        {
            id: 3,
            time: 'Daily'
        }
    ];
    timeValue = this.timeOptions;

    timeIncrementOptions: TimeIncrement[] = [
        {
            id: 1,
            name: '1D'
        },
        {
            id: 2,
            name: '5D'
        },
        {
            id: 3,
            name: '1W'
        },

        {
            id: 4,
            name: '2W'
        },
        {
            id: 5,
            name: '1M'
        },
        {
            id: 6,
            name: '2M'
        },
        {
            id: 7,
            name: '3M'
        },
        {
            id: 8,
            name: '6M'
        },
        {
            id: 9,
            name: '12M'
        },
        {
            id: 10,
            name: '24M'
        },
        {
            id: 11,
            name: 'SUM'
        },
        {
            id: 12,
            name: 'WIN'
        }
    ];
    timeIncrementValue = this.timeIncrementOptions[0];

    unitOptions: UnitMeasurement[] = [
        {
            id: 1,
            unit: 'KVA-All Meters'
        },
        {
            id: 2,
            unit: 'KVA-DER Gen Meters'
        },
        {
            id: 3,
            unit: 'KVA-Excluding DER Gen meters'
        },
        {
            id: 4,
            unit: 'KVAR-All Meters'
        },
        {
            id: 5,
            unit: 'KVAR-Der Gen Meters'
        },
        {
            id: 6,
            unit: 'KVAR-Excluding Der Gen Meters'
        },
        {
            id: 7,
            unit: 'KW-All Meters'
        },
        {
            id: 8,
            unit: 'KW-Der Gen Meters'
        },
        {
            id: 9,
            unit: 'KW-Excluding Der Gen Meters'
        }
    ];
    unitValue = this.unitOptions;

    chartTypeOptions = [
        {
            id: 1,
            type: 'Single'
        },
        {
            id: 2,
            type: 'Double'
        },
        {
            id: 3,
            type: 'Best'
        },
        {
            id: 4,
            type: 'Stacked'
        }
    ];
    chartTypeValue = this.chartTypeOptions;

    weatherOptions = [
        {
            id: 1,
            type: 'Daily F Temperature Max'
        },
        {
            id: 2,
            type: 'Daily F Temperature Min'
        },
        {
            id: 3,
            type: 'Daily F Temperature Avg'
        }
    ];
    weatherValue = this.weatherOptions;

    statisticOptions = [
        {
            id: 1,
            type: 'Minimum'
        },
        {
            id: 1,
            type: 'Maximum'
        },
        {
            id: 1,
            type: 'Median'
        },
        {
            id: 1,
            type: 'Average'
        }
    ];
    statisticValue = this.statisticOptions;

    meterData = [
        { date: '1/6/25', temp: 0.12, maximum: 0.24, overload: 0.08 },
        { date: '1/7/25', temp: 0.2, maximum: 0.24, overload: 0.1 },
        { date: '1/8/25', temp: 0.34, maximum: 0.24, overload: 0.21 },
        { date: '1/9/25', temp: 0.48, maximum: 0.24, overload: 0.03 },
        { date: '1/10/25', temp: 0.19, maximum: 0.24, overload: 0.056 },
        { date: '1/11/25', temp: 0.36, maximum: 0.24, overload: 0.0154 },
        { date: '1/12/25', temp: 0.28, maximum: 0.24, overload: 0.09 },
        { date: '1/13/25', temp: 0.14, maximum: 0.24, overload: 0.061 },
        { date: '1/14/25', temp: 0.3, maximum: 0.24, overload: 0.012 },
        { date: '1/15/25', temp: 0.22, maximum: 0.24, overload: 0.087 },
        { date: '1/16/25', temp: 0.17, maximum: 0.24, overload: 0.29 },
        { date: '1/17/25', temp: 0.21, maximum: 0.24, overload: 0.099 },
        { date: '1/18/25', temp: 0.32, maximum: 0.24, overload: 0.054 },
        { date: '1/19/25', temp: 0.41, maximum: 0.24, overload: 0.25 },
        { date: '1/20/25', temp: 0.52, maximum: 0.24, overload: 0.095 },
        { date: '1/21/25', temp: 0.27, maximum: 0.24, overload: 0.068 },
        { date: '1/22/25', temp: 0.18, maximum: 0.24, overload: 0.045 },
        { date: '1/23/25', temp: 0.45, maximum: 0.24, overload: 0.18 },
        { date: '1/24/25', temp: 0.51, maximum: 0.24, overload: 0.12 }
    ];
// Metric Chart
public series: Series[] = [
   
    {
      type: "line",
      data: [78, 65, 72, 75, 51, 34, 45, 56, 67, 78, 89, 90, 100, 78, 65, 72, 75, 51, 34, 45, 56, 67, 78, 89, 90, 100, 78, 65, 72, 75, 51, 34, 45, 56, 67, 78, 89, 90, 100, 78, 65, 72, 75, 51, 34, 45, 56, 67, 78, 89, 90, 100],
      name: "Temperature Type",
      color: "var(--kendo-color-warning)",
      axis: "Temperature Type",
    },
    {
      type: "column",
      data: [600, 1200, 656, 690, 568, 800, 1000, 623, 670, 845, 1800, 2400, 610, 600, 1200, 656, 690, 568, 800, 1000, 623, 670, 845, 1800, 2400, 610, 600, 1200, 656, 690, 568, 800, 1000, 623, 670, 845, 1800, 2400, 610, 600, 1200, 656, 690, 568, 800, 1000, 623, 670, 845, 1800, 2400, 610],
      name: "Unit of Measure",
      color: "var(--kendo-color-primary)",
      axis: "Unit of Measure",
    }
  ];

  public valueAxes: ValueAxis[] = [
    {
      name: "Unit of Measure",
      title: { text: "Unit of Measure" },
      color: "var(--kendo-color-on-app-surface)",
      min: 600,
      max: 3000,
      majorUnit: 600
    },
    {
      name: "Temperature Type",
      title: { text: "Temperature Type" },
      color: "var(--kendo-color-warning)",
      min: 0,
      max: 120,
      majorUnit: 20
    },
  ];

  public categories: string[] = [
    "1/12/25",
    "1/13/25",
    "1/14/25",
    "1/15/25",
    "1/16/25",
    "1/17/25",
    "1/18/25",
    "1/19/25",
    "1/20/25",
    "1/21/25",
    "1/22/25",
    "1/23/25",
    "1/24/25",
    "1/25/25",
    "1/26/25",
    "1/27/25",
    "1/28/25",
    "1/29/25",
    "1/30/25",
    "1/31/25",
    "2/1/25",
    "2/2/25",
    "2/3/25",
    "2/4/25",
    "2/5/25",
    "2/6/25",
    "2/7/25",
    "2/8/25",
    "2/9/25",
    "2/10/25",
    "2/11/25",
    "2/12/25",
    "2/13/25",
    "2/14/25",
    "2/15/25",
    "2/16/25",
    "2/17/25",
    "2/18/25",
    "2/19/25",
    "2/20/25",
    "2/21/25",
    "2/22/25",
    "2/23/25",
    "2/24/25",
    "2/25/25",
    "2/26/25",
    "2/27/25",
    "2/28/25",
    "3/1/25",
    "3/2/25",
    "3/3/25",
  ];
// Align the first two value axes to the left
  // and the last two to the right.
  //
  // Right alignment is done by specifying a
  // crossing value greater than or equal to
  // the number of categories.
  public crossingValues: number[] = [0, 1000];
  public maxTempThreshold = new Array(this.categories.length).fill(60);
}

interface TimeBasis {
    id?: number | null;
    time: string;
}

interface UnitMeasurement {
    id?: number | null;
    unit: string;
}

interface TimeIncrement {
    id: number;
    name: string;
}

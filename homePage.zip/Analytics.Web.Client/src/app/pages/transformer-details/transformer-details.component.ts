import { CommonModule } from '@angular/common';
import { Component, inject, OnInit, viewChild } from '@angular/core';
import { FusionChartComponent, FusionPageBaseComponent } from '@fusion/ngx-fusion';
import { SharedModule } from '../../modules/shared/shared.module';
import { ActivatedRoute } from '@angular/router';
import { heatMapdata } from './heat-data';
import { Meter, Transformer, Note } from '../../types';
import { Series, ValueAxis } from '@fusion/ngx-fusion/node_modules/@progress/kendo-angular-charts';
import { TransformerService } from '../../services/transformer/transformer.service';
import { MeterService } from '../../services/meter/meter.service';

@Component({
    selector: 'app-transformer-details',
    standalone: true,
    imports: [CommonModule, SharedModule],
    templateUrl: './transformer-details.component.html',
    styleUrls: ['./transformer-details.component.scss']
})
export class TransformerDetailsComponent extends FusionPageBaseComponent implements OnInit {
readonly chart = viewChild('chart', { read: FusionChartComponent });

    pointId: string | null = null;
    yearValue?: boolean;
    dateRangeValue?: { start: Date; end: Date };

    route = inject(ActivatedRoute);
    override ngOnInit(): void {
        const pointId = this.route.snapshot.paramMap.get('pointId');
        this.pointId = pointId;
        this.transformer = this.transformers.find((t) => t.point_id === this.pointId);
    }

    meterService = inject(MeterService);
    meters = this.meterService.meters;
    meterValue?: Meter;
    meter?: Meter;

    transformer?: Transformer;
    transformerService = inject(TransformerService);
    transformers = this.transformerService.transformers;

    notes: Note[] = [];

    // A variable to hold the new note text from the form
    newNoteText?: string = '';

   // Returns 30% of the provided rating, rounded to a sensible precision
    public getKvaFromRating(rating: number | string | undefined): string {
        if (rating === null || rating === undefined) {
            return 'N/A';
        }

        const num = typeof rating === 'number' ? rating : Number(rating);
        if (Number.isNaN(num)) {
            return 'N/A';
        }

        const kva = num * 0.3; // 30%
        return kva % 1 === 0 ? String(kva) : kva.toFixed(2);
    }

    // Method to push a new note to the list
    addNote(): void {
        if (this.newNoteText?.trim() !== '') {
            this.notes.push({
                eid: this.generateRandomEID(),
                text: this.newNoteText ?? '',
                timestamp: new Date()
            });
            // Clear the input field after adding the note
            this.newNoteText = '';
        }
    }

 // Show/Hide Map
    isHidden = true; // Initial state: hidden

    toggleVisibility() {
        this.isHidden = !this.isHidden; // Toggle the boolean value
    }

    // Generate Random EID
    generateRandomEID(): string {
        const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        const numbers = '0123456789';
        let eid = '';

        // Two Random Capital Letters
        for (let i = 0; i < 2; i++) {
            eid += letters.charAt(Math.floor(Math.random() * letters.length));
        }
        // Five Random Numbers
        for (let i = 0; i < 5; i++) {
            eid += numbers.charAt(Math.floor(Math.random() * numbers.length));
        }
        return eid;
    }

    public heatData = heatMapdata();
    public yAxisLabelContent = (e: { value: string }): string => {
        return hourLabels[e.value as unknown as number] || '';
    };
    public monthValue = (e: { value: string }): string => {
        return monthLabels[e.value as unknown as number] || '';
    };

    timeOptions: TimeBasis[] = [
        {
            id: 1,
            time: '15min'
        },
        {
            id: 2,
            time: 'Hourly'
        },
        {
            id: 3,
            time: 'Daily'
        }
    ];
    timeValue = this.timeOptions;

    timeIncrementOptions: TimeIncrement[] = [
        {
            id: 1,
            name: '1D'
        },
        {
            id: 2,
            name: '5D'
        },
        {
            id: 3,
            name: '1W'
        },

        {
            id: 4,
            name: '2W'
        },
        {
            id: 5,
            name: '1M'
        },
        {
            id: 6,
            name: '2M'
        },
        {
            id: 7,
            name: '3M'
        },
        {
            id: 8,
            name: '6M'
        },
        {
            id: 9,
            name: '12M'
        },
        {
            id: 10,
            name: '24M'
        },
        {
            id: 11,
            name: 'SUM'
        },
        {
            id: 12,
            name: 'WIN'
        }
    ];
    timeIncrementValue = this.timeIncrementOptions[0];

    unitOptions: UnitMeasurement[] = [
        {
            id: 1,
            unit: 'KVA-All Meters'
        },
        {
            id: 2,
            unit: 'KVA-DER Gen Meters'
        },
        {
            id: 3,
            unit: 'KVA-Excluding DER Gen meters'
        },
        {
            id: 4,
            unit: 'KVAR-All Meters'
        },
        {
            id: 5,
            unit: 'KVAR-Der Gen Meters'
        },
        {
            id: 6,
            unit: 'KVAR-Excluding Der Gen Meters'
        },
        {
            id: 7,
            unit: 'KW-All Meters'
        },
        {
            id: 8,
            unit: 'KW-Der Gen Meters'
        },
        {
            id: 9,
            unit: 'KW-Excluding Der Gen Meters'
        }
    ];
    unitValue = this.unitOptions;

    chartTypeOptions = [
        {
            id: 1,
            type: 'Single'
        },
        {
            id: 2,
            type: 'Double'
        },
        {
            id: 3,
            type: 'Best'
        },
        {
            id: 4,
            type: 'Stacked'
        }
    ];
    chartTypeValue = this.chartTypeOptions;

    weatherOptions = [
        {
            id: 1,
            type: 'Daily F Temperature Max'
        },
        {
            id: 2,
            type: 'Daily F Temperature Min'
        },
        {
            id: 3,
            type: 'Daily F Temperature Avg'
        }
    ];
    weatherValue = this.weatherOptions;

    statisticOptions = [
        {
            id: 1,
            type: 'Minimum'
        },
        {
            id: 1,
            type: 'Maximum'
        },
        {
            id: 1,
            type: 'Median'
        },
        {
            id: 1,
            type: 'Average'
        }
    ];
    statisticValue = this.statisticOptions;

    overloadedOptions = [
        {
            id: 1,
            type: 'Load Percent'
        }
    ];
    overloadedValue = this.overloadedOptions;

    transformerData = [
        { date: '1/6/25', value: 0.12, maximum: 0.24, overload: 0.08 },
        { date: '1/7/25', value: 0.2, maximum: 0.24, overload: 0.1 },
        { date: '1/8/25', value: 0.34, maximum: 0.24, overload: 0.21 },
        { date: '1/9/25', value: 0.48, maximum: 0.24, overload: 0.03 },
        { date: '1/10/25', value: 0.19, maximum: 0.24, overload: 0.056 },
        { date: '1/11/25', value: 0.36, maximum: 0.24, overload: 0.0154 },
        { date: '1/12/25', value: 0.28, maximum: 0.24, overload: 0.09 },
        { date: '1/13/25', value: 0.14, maximum: 0.24, overload: 0.061 },
        { date: '1/14/25', value: 0.3, maximum: 0.24, overload: 0.012 },
        { date: '1/15/25', value: 0.22, maximum: 0.24, overload: 0.087 },
        { date: '1/16/25', value: 0.17, maximum: 0.24, overload: 0.29 },
        { date: '1/17/25', value: 0.21, maximum: 0.24, overload: 0.099 },
        { date: '1/18/25', value: 0.32, maximum: 0.24, overload: 0.054 },
        { date: '1/19/25', value: 0.41, maximum: 0.24, overload: 0.25 },
        { date: '1/20/25', value: 0.52, maximum: 0.24, overload: 0.095 },
        { date: '1/21/25', value: 0.27, maximum: 0.24, overload: 0.068 },
        { date: '1/22/25', value: 0.18, maximum: 0.24, overload: 0.045 },
        { date: '1/23/25', value: 0.45, maximum: 0.24, overload: 0.18 },
        { date: '1/24/25', value: 0.51, maximum: 0.24, overload: 0.12 }
    ];

// Metric Chart
public series: Series[] = [
   
    {
      type: "line",
      data: [78, 65, 72, 75, 51, 34, 45, 56, 67, 78, 89, 90, 100, 78, 65, 72, 75, 51, 34, 45, 56, 67, 78, 89, 90, 100, 78, 65, 72, 75, 51, 34, 45, 56, 67, 78, 89, 90, 100, 78, 65, 72, 75, 51, 34, 45, 56, 67, 78, 89, 90, 100],
      name: "Temperature Type",
      color: "var(--kendo-color-warning)",
      axis: "Temperature Type",
    },
    {
      type: "column",
      data: [600, 1200, 656, 690, 568, 800, 1000, 623, 670, 845, 1800, 2400, 610, 600, 1200, 656, 690, 568, 800, 1000, 623, 670, 845, 1800, 2400, 610, 600, 1200, 656, 690, 568, 800, 1000, 623, 670, 845, 1800, 2400, 610, 600, 1200, 656, 690, 568, 800, 1000, 623, 670, 845, 1800, 2400, 610],
      name: "Unit of Measure",
      color: "var(--kendo-color-primary)",
      axis: "Unit of Measure",
    }
  ];

  public valueAxes: ValueAxis[] = [
    {
      name: "Unit of Measure",
      title: { text: "Unit of Measure" },
      color: "var(--kendo-color-on-app-surface)",
      min: 600,
      max: 3000,
      majorUnit: 600
    },
    {
      name: "Temperature Type",
      title: { text: "Temperature Type" },
      color: "var(--kendo-color-warning)",
      min: 0,
      max: 120,
      majorUnit: 20
    },
  ];

  public categories: string[] = [
    "1/12/25",
    "1/13/25",
    "1/14/25",
    "1/15/25",
    "1/16/25",
    "1/17/25",
    "1/18/25",
    "1/19/25",
    "1/20/25",
    "1/21/25",
    "1/22/25",
    "1/23/25",
    "1/24/25",
    "1/25/25",
    "1/26/25",
    "1/27/25",
    "1/28/25",
    "1/29/25",
    "1/30/25",
    "1/31/25",
    "2/1/25",
    "2/2/25",
    "2/3/25",
    "2/4/25",
    "2/5/25",
    "2/6/25",
    "2/7/25",
    "2/8/25",
    "2/9/25",
    "2/10/25",
    "2/11/25",
    "2/12/25",
    "2/13/25",
    "2/14/25",
    "2/15/25",
    "2/16/25",
    "2/17/25",
    "2/18/25",
    "2/19/25",
    "2/20/25",
    "2/21/25",
    "2/22/25",
    "2/23/25",
    "2/24/25",
    "2/25/25",
    "2/26/25",
    "2/27/25",
    "2/28/25",
    "3/1/25",
    "3/2/25",
    "3/3/25",
  ];


  // Align the first two value axes to the left
  // and the last two to the right.
  //
  // Right alignment is done by specifying a
  // crossing value greater than or equal to
  // the number of categories.
  public crossingValues: number[] = [0, 1000];
public maxTempThreshold = new Array(this.categories.length).fill(80);
}

const hourLabels: Record<number, string> = {
    0: '12am',
    1: '2am',
    2: '4am',
    3: '6am',
    4: '8am',
    5: '10am',
    6: '12pm',
    7: '2pm',
    8: '4pm',
    9: '6pm',
    10: '8pm',
    11: '10pm',
    12: '11:59pm'
};

const monthLabels: Record<number, string> = {
    1: '1/1/25',
    2: '1/2/25',
    3: '1/3/25',
    4: '1/4/25',
    5: '1/5/25',
    6: '1/6/25',
    7: '1/7/25',
    8: '1/8/25',
    9: '1/9/25',
    10: '1/10/25',
    11: '1/11/25',
    12: '1/12/25'
};

interface TimeBasis {
    id?: number | null;
    time: string;
}

interface UnitMeasurement {
    id?: number | null;
    unit: string;
}

interface TimeIncrement {
    id: number;
    name: string;
}

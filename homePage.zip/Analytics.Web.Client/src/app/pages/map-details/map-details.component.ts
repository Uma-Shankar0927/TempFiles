import { CommonModule } from '@angular/common';
import {
    FusionDataGridComponent,
    FusionDialogComponent,
    FusionGridCellComponent,
    FusionGridContainerComponent,
    FusionGridRowComponent,
    FusionPageBaseComponent
} from '@fusion/ngx-fusion';
import { Component, inject, OnInit, viewChild, AfterViewInit } from '@angular/core';
import { FUSION_GRID_CONTAINER } from '@fusion/ngx-fusion';
import { SharedModule } from '../../modules/shared/shared.module';
import { ActivatedRoute } from '@angular/router';
import { AlgorithmFilterCellComponent } from "../../components/algorithm-filter-cell/algorithm-filter-cell.component";
import { MeterService } from '../../services/meter/meter.service';
import { CircuitService } from '../../services/circuit/circuit.service';
import { Meter, Transformer, Note, Circuit } from '../../types';
import { TransformerService } from '../../services/transformer/transformer.service';
import { algorithmFilter, algorithmFilterProperty } from '../../tools';
import { SecurityService } from '../../services/security/security.service';
import { UtilityTypeFilterCellComponent } from '../../components/utility-type-filter-cell/utility-type-filter-cell.component';

@Component({
    imports: [
        FUSION_GRID_CONTAINER,
        FusionGridCellComponent,
        FusionGridRowComponent,
        FusionGridContainerComponent,
        CommonModule,
        AlgorithmFilterCellComponent,
        SharedModule,
UtilityTypeFilterCellComponent
    ],
    selector: 'app-map-details',
    standalone: true,
    templateUrl: './map-details.component.html',
    styleUrls: ['./map-details.component.scss']
})
export class MapDetailsComponent extends FusionPageBaseComponent implements OnInit, AfterViewInit {
    readonly securityService = inject(SecurityService);

    private readonly _activatedRoute = inject(ActivatedRoute);
    private readonly _dataGrid = viewChild.required(FusionDataGridComponent);


    componentDialog = viewChild.required('componentDialog', { read: FusionDialogComponent });
    pointId: string | null = null;
    yearValue?: boolean;
    dateRangeValue?: { start: Date; end: Date };
    meterId: string | null = null;

    selectedMeter: Meter | null = null; // Initialize the selected meter as null

    onItemClick(meter: Meter): void {
        // When a meter is clicked, set it as the new selected meter
        this.selectedMeter = meter;
    }

    route = inject(ActivatedRoute);
    override ngOnInit(): void {
        const meterId = this.route.snapshot.paramMap.get('meterId');
        this.meterId = meterId;
        this.meter = this.meters.find((m) => m.meter_number === this.meterId);
    }

    meter?: Meter;
    meterService = inject(MeterService);
    meters = this.meterService.meters;

    transformer?: Transformer;
    transformerService = inject(TransformerService);
    transformers = this.transformerService.transformers;

    circuitService = inject(CircuitService);
    circuits: Circuit[] = this.circuitService.circuits;
    circuit?: Circuit;


    notes: Note[] = [];

    // A variable to hold the new note text from the form
    newNoteText?: string = '';

    // Method to push a new note to the list
    addNote(): void {
        if (this.newNoteText?.trim() !== '') {
            this.notes.push({
                eid: this.generateRandomEID(),
                text: this.newNoteText ?? '',
                timestamp: new Date()
            });
            // Clear the input field after adding the note
            this.newNoteText = '';
        }
    }
    // Filters
    utilityTypesOptions = [{id: 1, name: 'Electric'}, {id: 2, name: 'Gas'}, {id: 3, name: 'Solar'}];
    utilityTypesValue = this.utilityTypesOptions;
    meterStatusOptions = [{id: 1, name: 'Active'}, {id: 2, name: 'Inactive'}, {id: 3, name: 'Removed'}];
    meterStatusValue = this.meterStatusOptions;

// Search Filtering
public gridData: Meter[] = this.meterService.meters;

public filterAll(inputValue: string): void {
  if (!inputValue) {
    this._dataGrid().gridFilterService?.filter({ filters: [], logic: 'or' });
    return;
  }

  const filters = [
    { field: 'meter_number', operator: 'contains', value: inputValue },
    { field: 'utility_type', operator: 'contains', value: inputValue },
    { field: 'status', operator: 'contains', value: inputValue },
    { field: 'address', operator: 'contains', value: inputValue },
    { field: 'city', operator: 'contains', value: inputValue },
    { field: 'account_number', operator: 'contains', value: inputValue },
    { field: 'point_id', operator: 'contains', value: inputValue },
    { field: 'rating', operator: 'contains', value: inputValue },
  ];
  this._dataGrid().gridFilterService?.filter({ filters: filters, logic: 'or' });
}


inputValue: string | null = null;

 clearInput() {
       
        this.inputValue = '';
 }

// End Search Filtering

 ngAfterViewInit(): void {
        const routeSnapshot = this._activatedRoute.snapshot;
        const filterProperty = routeSnapshot.queryParamMap.get('filterProperty');
        const filterValue = routeSnapshot.queryParamMap.get('filterValue');

        if (!filterProperty || !filterValue) {
            return;
        }

        const dataGrid = this._dataGrid();
        if (!dataGrid.gridFilterService) {
            return;
        }

        // Build filter, if filterProperty is algorithm then we need to use 'contains' operator as the value is an array
        const filter = {
            field: filterProperty === 'algorithm' ? algorithmFilterProperty : filterProperty,
            operator: filterProperty === 'algorithm' ? algorithmFilter : 'eq',
            value: filterValue
        };

        dataGrid.gridFilterService.filter({
            filters: [
                filter
            ],
            logic: 'and'
        });
    }





// Dialog (Modal)

    componentDialogDone(): void {
        // this.fusion.message.globalMessage('Done');
        this.componentDialog().close('Done');
    }

    // Simulate a busy action for 5 seconds
    actionBusy(): Promise<void> {
        return this.fusion.busy.performActionAsync('actionBusy', this.fusion.tools.wait(5000));
    }

    // Generate Random EID
    generateRandomEID(): string {
        const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        const numbers = '0123456789';
        let eid = '';

        // Two Random Capital Letters
        for (let i = 0; i < 2; i++) {
            eid += letters.charAt(Math.floor(Math.random() * letters.length));
        }
        // Five Random Numbers
        for (let i = 0; i < 5; i++) {
            eid += numbers.charAt(Math.floor(Math.random() * numbers.length));
        }
        return eid;
    }

    muteOptions = [
        {
            id: 1,
            duration: '1 Month'
        },
        {
            id: 2,
            duration: '6 Months'
        },
        {
            id: 3,
            duration: '12 Months'
        }
    ];
    muteValue = this.muteOptions;

    feedbackOptions = [
        {
            id: 1,
            reason: 'IMC'
        },
        {
            id: 2,
            reason: 'NCF'
        },
        {
            id: 3,
            reason: 'Safety'
        },
        {
            id: 4,
            reason: 'Theft'
        },
        {
            id: 5,
            reason: 'CIS Review Only'
        }
    ];
    feedbackValue = this.feedbackOptions;

    listOptions = [
        {
            id: 1,
            reason: 'Hot Socket'
        },
        {
            id: 2,
            reason: 'Half Voltage'
        },
        {
            id: 3,
            reason: 'Double Voltage'
        },
        {
            id: 4,
            reason: 'Miscellaneous Voltage'
        },
        {
            id: 5,
            reason: 'Frequent Outages'
        },
        {
            id: 6,
            reason: 'Targeted No Meters'
        },
        {
            id: 7,
            reason: 'Communicating with No Reads'
        },
        {
            id: 8,
            reason: 'Zero Electricity Usage'
        },
        {
            id: 9,
            reason: 'RP Removed Meters'
        },
        {
            id: 10,
            reason: 'Reverse Energy'
        }
    ];
    listValue = this.listOptions;

timeIncrementOptions: TimeIncrement[] = [
        {
            id: 1,
            name: '1D'
        },
        {
            id: 2,
            name: '5D'
        },
        {
            id: 3,
            name: '1W'
        },

        {
            id: 4,
            name: '2W'
        },
        {
            id: 5,
            name: '1M'
        },
        {
            id: 6,
            name: '2M'
        },
        {
            id: 7,
            name: '3M'
        },
        {
            id: 8,
            name: '6M'
        },
        {
            id: 9,
            name: '12M'
        },
        {
            id: 10,
            name: '24M'
        },
        {
            id: 11,
            name: 'SUM'
        },
        {
            id: 12,
            name: 'WIN'
        }
    ];
    timeIncrementValue = this.timeIncrementOptions[0];

    txRatingOptions = [
        { id: 1, name: '1' },
        { id: 2, name: '2' },
        { id: 3, name: '3' },
        { id: 4, name: '4' },
        { id: 5, name: '5' }
    ];
    txRatingValue = this.txRatingOptions;
}

interface TimeIncrement {
    id: number;
    name: string;
}

import { CommonModule } from '@angular/common';
import { AfterViewInit, Component, inject, viewChild } from '@angular/core';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { FUSION_DATA_GRID, FUSION_GRID_CONTAINER, FusionDataGridComponent, FusionDataGridSelectionEvent, FusionPageBaseComponent } from '@fusion/ngx-fusion';
import { AlgorithmFilterCellComponent } from "../../components/algorithm-filter-cell/algorithm-filter-cell.component";
import { TransformerFilterCellComponent } from '../../components/transformer-status-filter-cell/transformer-status-filter-cell.component';
import { SharedModule } from '../../modules/shared/shared.module';
import { CircuitService } from '../../services/circuit/circuit.service';
import { MeterService } from '../../services/meter/meter.service';
import { SecurityService } from '../../services/security/security.service';
import { TransformerService } from '../../services/transformer/transformer.service';
import { algorithmFilter, algorithmFilterProperty } from '../../tools';
import { Circuit, Meter } from '../../types';
import { PcbFilterCellComponent } from '../../components/pcb-filter-cell/pcb-filter-cell.component';
import { UtilityTypeFilterCellComponent } from '../../components/utility-type-filter-cell/utility-type-filter-cell.component';

@Component({
    imports: [FUSION_DATA_GRID, CommonModule, FUSION_GRID_CONTAINER, SharedModule, RouterModule, AlgorithmFilterCellComponent, TransformerFilterCellComponent, PcbFilterCellComponent, UtilityTypeFilterCellComponent],
    selector: 'app-explorer',
    standalone: true,
    templateUrl: './explorer.component.html'
})
export class ExplorerComponent extends FusionPageBaseComponent implements AfterViewInit {
    readonly securityService = inject(SecurityService);

    private readonly _activatedRoute = inject(ActivatedRoute);
    private readonly _dataGrid = viewChild.required(FusionDataGridComponent);

    selectedIndex = 0;
    meterId?: string;
    pointId?: string;
    selected: string[] = [];
    meter?: Meter;
    meterService = inject(MeterService);
    meters = this.meterService.meters;

    meterNumberValue?: number;
    addressValue?: string;
    cityValue?: string;
    accountNumberValue?: number;
    pointIdValue?: number;

    transformer?: Transformer;
    transformerService = inject(TransformerService);
    transformers = this.transformerService.transformers;
    transformerValue?: Transformer;

// Dummy data for dropdowns
    transformerStatusOptions: { id: number; status: string }[] = [
        { id: 1, status: 'Normal' },
        { id: 2, status: 'Underloaded' },
        { id: 3, status: 'Watchlist' },
        { id: 4, status: 'Overloaded' },
        { id: 5, status: 'Immediate' }
    ];
    transformerStatusValue?: string;

    transformerPointIdOptions: { id: number; pointId: string }[] = [
        { id: 1, pointId: '00030043354' },
        { id: 2, pointId: '00030043355' },
        { id: 3, pointId: '00030043356' }
    ];
    transformerPointIdValue?: string;

    transformerPolePadOptions: { id: number; poleId: string }[] = [
        { id: 1, poleId: '0043354' },
        { id: 2, poleId: '0043355' },
        { id: 3, poleId: '0043356' }
    ];
    transformerPolePadValue?: string;

    transformerSubstationOptions: { id: number; substationId: string }[] = [
        { id: 1, substationId: 'Brookwood' },
        { id: 2, substationId: 'Columbia Industrial Park' },
        { id: 3, substationId: 'Kendrick' }
    ];
    transformerSubstationValue?: string;

    transformerCircuitOptions: { id: number; circuitId: string }[] = [
        { id: 1, circuitId: '14042' },
        { id: 2, circuitId: '78602' },
        { id: 3, circuitId: '18322' }
    ];
    transformerCircuitValue?: string;

    transformerCrewQuarterOptions: { id: number; crewQuarterId: string }[] = [
        { id: 1, crewQuarterId: 'Columbia Metro' },
        { id: 2, crewQuarterId: 'Greenwood' },
        { id: 3, crewQuarterId: 'Charleston' }
    ];
    transformerCrewQuarterValue?: string;

    transformerDurationOptions: { id: number; durationId: string }[] = [
        { id: 1, durationId: 'All' },
        { id: 2, durationId: 'Daily' },
        { id: 3, durationId: 'Weekly' },
        { id: 4, durationId: 'Monthly' },
        { id: 5, durationId: 'Yearly' }
    ];
    transformerDurationValue?: string;

    meterCount?: number = this.transformers.length; // From transformer service

    circuitService = inject(CircuitService);
    circuits = this.circuitService.circuits;
    circuitValue?: Circuit;

// Algorithm Dropdown
    public RevenueAssuranceAlgorithmOptions = [
    { name: 'All', id: "all" },
    { name: 'All Metering', id: "all_metering" },
    { name: 'All Revenue Protection', id: "all_revenue_protection" },
    { name: 'All Customer Service', id: "all_customer_service" },
    { name: 'Hot Socket', id: "hot_socket" },
    { name: 'Miscellaneous Voltage', id: "miscellaneous_voltage" },
    { name: 'Double Voltage', id: "double_voltage" },
    { name: 'No Algorithms', id: "no_algorithms" },
    { name: 'Frequent Outages', id: "frequent_outages" },
    { name: 'Targeted No Meters', id: "targeted_no_meters" },
    { name: 'Communicating with No Reads', id: "communicating_with_no_reads" },
    { name: 'Zero Electricity Usage', id: "zero_electricity_usage" },
    { name: 'RP Removed Meters', id: "rp_removed_meters" },
    { name: 'Reverse Energy', id: "reverse_energy" }
    ];
    public RevenueAssuranceAlgorithmValue: string | null = null;

    public DistOpsAlgorithmOptions = [
    { name: 'Hot Socket', id: "hot_socket" },
    { name: 'Miscellaneous Voltage', id: "miscellaneous_voltage" },
    { name: 'Double Voltage', id: "double_voltage" },
    { name: 'No Algorithms', id: "no_algorithms" },
    { name: 'Frequent Outages', id: "frequent_outages" },
    { name: 'Targeted No Meters', id: "targeted_no_meters" },
    { name: 'Communicating with No Reads', id: "communicating_with_no_reads" },
    { name: 'Zero Electricity Usage', id: "zero_electricity_usage" },
    { name: 'RP Removed Meters', id: "rp_removed_meters" },
    { name: 'Reverse Energy', id: "reverse_energy" }
    ];
    public DistOpsAlgorithmValue: string | null = null;
// End Algorithm Dropdown


// Selected Checkbox
 handleSelectionChange = (event: FusionDataGridSelectionEvent): void => {
        this.fusion.message.globalMessage(JSON.stringify(event.selectedRows?.[0]?.dataItem), undefined);
    };

// Meter Search Filtering
public meterGridData: Meter[] = this.meterService.meters;

public filterAllMeters(inputValue: string): void {
  if (!inputValue) {
    this._dataGrid().gridFilterService?.filter({ filters: [], logic: 'or' });
    return;
  }

  const filters = [
    { field: 'meter_number', operator: 'contains', value: inputValue },
    { field: 'utility_type', operator: 'contains', value: inputValue },
    { field: 'status', operator: 'contains', value: inputValue },
    { field: 'address', operator: 'contains', value: inputValue },
    { field: 'city', operator: 'contains', value: inputValue },
    { field: 'account_number', operator: 'contains', value: inputValue },
    { field: 'point_id', operator: 'contains', value: inputValue },
    { field: 'rating', operator: 'contains', value: inputValue },
  ];
  this._dataGrid().gridFilterService?.filter({ filters: filters, logic: 'or' });
}


meterInputValue: string | null = null;

 clearMeterInput() {

        this.meterInputValue = '';
 }

// End Meter Search Filtering

// Transformer Search Filtering
public transformerGridData = this.transformerService.transformers;

public filterAllTransformers(inputValue: string): void {
  if (!inputValue) {
    this._dataGrid().gridFilterService?.filter({ filters: [], logic: 'or' });
    return;
  }

  const filters = [
    { field: 'status', operator: 'contains', value: inputValue },
    { field: 'point_id', operator: 'contains', value: inputValue },
    { field: 'pole_id', operator: 'contains', value: inputValue },
    { field: 'rating', operator: 'contains', value: inputValue },
    { field: 'pcb', operator: 'contains', value: inputValue },
    { field: 'active_meter_count', operator: 'contains', value: inputValue },
    { field: 'substation_name', operator: 'contains', value: inputValue },
    { field: 'crew_quarter', operator: 'contains', value: inputValue },
  ];
  this._dataGrid().gridFilterService?.filter({ filters: filters, logic: 'or' });
}

transformerInputValue: string | null = null;

 clearTransformerInput() {

        this.transformerInputValue = '';
 }

    // Returns 30% of the provided rating, rounded to a sensible precision
    public getKvaFromRating(rating: number | string | undefined): string {
        if (rating === null || rating === undefined) {
            return 'N/A';
        }

        const num = typeof rating === 'number' ? rating : Number(rating);
        if (Number.isNaN(num)) {
            return 'N/A';
        }

        const kva = num * 0.3; // 30%
        return kva % 1 === 0 ? String(kva) : kva.toFixed(2);
    }

// End Transformer Search Filtering

    
    ngAfterViewInit(): void {
        const routeSnapshot = this._activatedRoute.snapshot;
        const filterProperty = routeSnapshot.queryParamMap.get('filterProperty');
        const filterValue = routeSnapshot.queryParamMap.get('filterValue');

        if (!filterProperty || !filterValue) {
            return;
        }

        const dataGrid = this._dataGrid();
        if (!dataGrid.gridFilterService) {
            return;
        }

        // Build filter, if filterProperty is algorithm then we need to use 'contains' operator as the value is an array
        const filter = {
            field: filterProperty === 'algorithm' ? algorithmFilterProperty : filterProperty,
            operator: filterProperty === 'algorithm' ? algorithmFilter : 'eq',
            value: filterValue
        };

        dataGrid.gridFilterService.filter({
            filters: [
                filter
            ],
            logic: 'and'
        });
    }

    // sets the cell background color for the statuses
    public statusColor(status: string): string {
        let color;

        if (status === 'underloaded') {
            color = 'var(--kendo-color-primary)' as string;
        } else if (status === 'normal') {
            color = 'var(--kendo-color-success)' as string;
        } else if (status === 'watchlist') {
            color = 'var(--kendo-color-warning)' as string;
        } else if (status === 'overloaded') {
            color = '#fc9700ff' as string;
        } else color = 'var(--kendo-color-error)' as string;

        return color;
    }

    public meterColor(meter_type: string): string {
        let bgColor;

        if (meter_type === 'solar') {
            bgColor = 'var(--kendo-color-warning)' as string;
        } else {
            bgColor = 'transparent';
        }

        return bgColor;
    }


}

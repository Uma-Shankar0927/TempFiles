import { Series, ValueAxis } from '@fusion/ngx-fusion/node_modules/@progress/kendo-angular-charts';
import { CommonModule } from '@angular/common';
import { Component, inject, OnInit, viewChild } from '@angular/core';
import { FUSION_CHART, FusionDialogComponent, FusionPageBaseComponent } from '@fusion/ngx-fusion';
import { SharedModule } from '../../modules/shared/shared.module';
import { ActivatedRoute } from '@angular/router';
import { MeterService } from '../../services/meter/meter.service';
import { Meter, Note, Transformer } from '../../types';
import { SecurityService } from '../../services/security/security.service';

@Component({
    imports: [CommonModule, SharedModule, FusionDialogComponent, FUSION_CHART],
    selector: 'app-meter-details',
    standalone: true,
    templateUrl: './meter-details.component.html',
    styleUrls: ['./meter-details.component.scss']
})
export class MeterDetailsComponent extends FusionPageBaseComponent implements OnInit {
    readonly securityService = inject(SecurityService);
    componentDialog = viewChild.required('componentDialog', { read: FusionDialogComponent });
    eventDialog = viewChild.required('eventDialog', { read: FusionDialogComponent });
    meterId: string | null = null;
    dateRangeValue?: { start: Date; end: Date };
    yearValue?: boolean;
    selectedIndex?: 2;
    displayValueOnly = true;
    transformer: Transformer | null = null;

    setEditMode(): void {
        this.displayValueOnly = !this.displayValueOnly; // or !this.displayValueOnly to toggle
    }

    route = inject(ActivatedRoute);
    override ngOnInit(): void {
        const meterId = this.route.snapshot.paramMap.get('meterId');
        this.meterId = meterId;
        this.meter = this.meters.find((m) => m.meter_number === this.meterId);
    }

    // Show/Hide Map
    isHidden = true; // Initial state: hidden

    toggleVisibility() {
        this.isHidden = !this.isHidden; // Toggle the boolean value
    }

    // Dialog (Modal)
    componentDialogDone(): void {
        this.fusion.message.globalMessage('Done');
        this.componentDialog().close('Done');
    }

    // Events Dialog Modal
     eventDialogDone(): void {
        this.fusion.message.globalMessage('Done');
        this.eventDialog().close('Done');
    }

    readonly eventData = [
        { date: '01/01/25', event: '165985', name: 'Event Name', text: 'This is a description of the event' },
    ];

    notes: Note[] = [];

    // Simulate a busy action for 5 seconds
    actionBusy(): Promise<void> {
        return this.fusion.busy.performActionAsync('actionBusy', this.fusion.tools.wait(5000));
    }

    // A variable to hold the new note text from the form
    newNoteText?: string = '';

    // Method to push a new note to the list
    addNote(): void {
        if (this.newNoteText?.trim() !== '') {
            this.notes.push({
                eid: this.generateRandomEID(),
                text: this.newNoteText ?? '',
                timestamp: new Date()
            });
            // Clear the input field after adding the note
            this.newNoteText = '';
        }
    }

    // Generate Random EID
    generateRandomEID(): string {
        const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        const numbers = '0123456789';
        let eid = '';

        // Two Random Capital Letters
        for (let i = 0; i < 2; i++) {
            eid += letters.charAt(Math.floor(Math.random() * letters.length));
        }
        // Five Random Numbers
        for (let i = 0; i < 5; i++) {
            eid += numbers.charAt(Math.floor(Math.random() * numbers.length));
        }
        return eid;
    }

    meter?: Meter;
    meterService = inject(MeterService);
    meters = this.meterService.meters;

    timeOptions: TimeBasis[] = [
        {
            id: 1,
            time: '15min'
        },
        {
            id: 2,
            time: 'Hourly'
        }
    ];
    timeValue = this.timeOptions;

    timeIncrementOptions: TimeIncrement[] = [
        {
            id: 1,
            name: '1D'
        },
        {
            id: 2,
            name: '5D'
        },
        {
            id: 3,
            name: '1W'
        },

        {
            id: 4,
            name: '2W'
        },
        {
            id: 5,
            name: '1M'
        },
        {
            id: 6,
            name: '2M'
        },
        {
            id: 7,
            name: '3M'
        },
        {
            id: 8,
            name: '6M'
        },
        {
            id: 9,
            name: '12M'
        },
        {
            id: 10,
            name: '24M'
        },
        {
            id: 11,
            name: 'SUM'
        },
        {
            id: 12,
            name: 'WIN'
        }
    ];
    timeIncrementValue = this.timeIncrementOptions[0];

    unitOptions: UnitMeasurement[] = [
        {
            id: 1,
            unit: 'KVA-All Meters'
        },
        {
            id: 2,
            unit: 'KVA-DER Gen Meters'
        },
        {
            id: 3,
            unit: 'KVA-Excluding DER Gen meters'
        },
        {
            id: 4,
            unit: 'KVAR-All Meters'
        },
        {
            id: 5,
            unit: 'KVAR-Der Gen Meters'
        },
        {
            id: 6,
            unit: 'KVAR-Excluding Der Gen Meters'
        },
        {
            id: 7,
            unit: 'KW-All Meters'
        },
        {
            id: 8,
            unit: 'KW-Der Gen Meters'
        },
        {
            id: 9,
            unit: 'KW-Excluding Der Gen Meters'
        },
        {
            id: 10,
            unit: 'CCF'
        }
    ];
    unitValue: UnitMeasurement | null = this.unitOptions[0] ?? null;

    chartTypeOptions = [
        {
            id: 1,
            type: 'Single'
        },
        {
            id: 2,
            type: 'Double'
        },
        {
            id: 3,
            type: 'Best'
        },
        {
            id: 4,
            type: 'Stacked'
        }
    ];
    chartTypeValue = this.chartTypeOptions;

    weatherOptions = [
        {
            id: 1,
            type: 'Daily F Temperature Max'
        },
        {
            id: 2,
            type: 'Daily F Temperature Min'
        },
        {
            id: 3,
            type: 'Daily F Temperature Avg'
        }
    ];
    weatherValue = this.weatherOptions;

    statisticOptions = [
        {
            id: 1,
            type: 'Minimum'
        },
        {
            id: 1,
            type: 'Maximum'
        },
        {
            id: 1,
            type: 'Median'
        },
        {
            id: 1,
            type: 'Average'
        }
    ];
    statisticValue = this.statisticOptions;

    leadOptions = [
        {
        id: 1, 
        lead: '12-15-2025 03:45 PM'},
        {
            id: 2,
            lead: '12-16-2025 04:00 PM'
        },
        {
            id: 3,
            lead: '12-17-2025 01:30 PM'         
        }
    ];
 leadValue = this.leadOptions;

    muteOptions = [
        {
            id: 1,
            duration: '1 Month'
        },
        {
            id: 2,  
            duration: '6 Months'
        },
        {
            id: 3,
            duration: '12 Months'
        }
    ];
    muteValue = this.muteOptions;

    feedbackOptions = [
        {
            id: 1,
            reason: 'IMC'
        },
        {
            id: 2,
            reason: 'NCF'
        },
        {
            id: 3,
            reason: 'Safety'
        },
        {
            id: 4,
            reason: 'Theft'
        },
        {
            id: 5,
            reason: 'CIS Review Only'
        }
    ];
    feedbackValue = this.feedbackOptions;

    listOptions = [
        {
            id: 1,
            reason: 'Hot Socket'
        },
        {
            id: 2,
            reason: 'Half Voltage'
        },
        {
            id: 3,
            reason: 'Double Voltage'
        },
        {
            id: 4,
            reason: 'Miscellaneous Voltage'
        },
        {
            id: 5,
            reason: 'Frequent Outages'
        },
        {
            id: 6,
            reason: 'Targeted No Meters'
        },
        {
            id: 7,
            reason: 'Communicating with No Reads'
        },
        {
            id: 8,
            reason: 'Zero Electricity Usage'
        },
        {
            id: 9,
            reason: 'RP Removed Meters'
        },
        {
            id: 10,
            reason: 'Reverse Energy'
        }
    ];
    listValue = this.listOptions;

    meterData = [
        { date: '1/6/25', temp: 75, maximum: 25, overload: 8 },
        { date: '1/7/25', temp: 75, maximum: 25, overload: 1 },
        { date: '1/8/25', temp: 76, maximum: 25, overload: 2 },
        { date: '1/9/25', temp: 74, maximum: 25, overload: 3 },
        { date: '1/10/25', temp: 74, maximum: 25, overload: 1 },
        { date: '1/11/25', temp: 78, maximum: 25, overload: 2 },
        { date: '1/12/25', temp: 75, maximum: 25, overload: 1 },
        { date: '1/13/25', temp: 76, maximum: 25, overload: 1 },
        { date: '1/14/25', temp: 74, maximum: 25, overload: 1 },
        { date: '1/15/25', temp: 75, maximum: 25, overload: 1 },
        { date: '1/16/25', temp: 74, maximum: 25, overload: 1 },
        { date: '1/17/25', temp: 74, maximum: 25, overload: 1 },
        { date: '1/18/25', temp: 73, maximum: 25, overload: 1 },
        { date: '1/19/25', temp: 71, maximum: 25, overload: 1 },
        { date: '1/20/25', temp: 71, maximum: 25, overload: 1 },
        { date: '1/21/25', temp: 72, maximum: 25, overload: 1 },
        { date: '1/22/25', temp: 72, maximum: 25, overload: 1 },
        { date: '1/23/25', temp: 75, maximum: 25, overload: 1 },
        { date: '1/24/25', temp: 75, maximum: 25, overload: 1 }
    ];

    nicTimeOptions: NicTimeBasis[] = [
        {
            id: 1,
            time: 'Actual'
        },
        {
            id: 2,
            time: 'Not Actual'
        }
    ];
    nicTimeValue = this.nicTimeOptions;

    factOptions: FactCategory[] = [
        {
            id: 1,
            category: 'NIC Events'
        },
        {
            id: 2,
            category: 'Meter Events'
        }
    ];

    factValue = this.factOptions;

   eventOptions: string[] = [
       'Self Read',
       'Registration Failure',
       'Informational Items'
   ];
    eventValue?: string[] = [];


// Metric Chart
public series: Series[] = [
   
    {
      type: "line",
      data: [78, 65, 72, 75, 51, 34, 45, 56, 67, 78, 89, 90, 100, 78, 65, 72, 75, 51, 34, 45, 56, 67, 78, 89, 90, 100, 78, 65, 72, 75, 51, 34, 45, 56, 67, 78, 89, 90, 100, 78, 65, 72, 75, 51, 34, 45, 56, 67, 78, 89, 90, 100],
      name: "Temperature Type",
      color: "var(--kendo-color-warning)",
      axis: "Temperature Type",
    },
    {
      type: "column",
      data: [600, 1200, 656, 690, 568, 800, 1000, 623, 670, 845, 1800, 2400, 610, 600, 1200, 656, 690, 568, 800, 1000, 623, 670, 845, 1800, 2400, 610, 600, 1200, 656, 690, 568, 800, 1000, 623, 670, 845, 1800, 2400, 610, 600, 1200, 656, 690, 568, 800, 1000, 623, 670, 845, 1800, 2400, 610],
      name: "Unit of Measure",
      color: "var(--kendo-color-primary)",
      axis: "Unit of Measure",
    }
  ];

  public valueAxes: ValueAxis[] = [
    {
      name: "Unit of Measure",
      title: { text: "Unit of Measure" },
      color: "var(--kendo-color-on-app-surface)",
      min: 600,
      max: 3000,
      majorUnit: 600
    },
    {
      name: "Temperature Type",
      title: { text: "Temperature Type" },
      color: "var(--kendo-color-warning)",
      min: 0,
      max: 120,
      majorUnit: 20
    },
  ];

  public categories: string[] = [
    "1/12/25",
    "1/13/25",
    "1/14/25",
    "1/15/25",
    "1/16/25",
    "1/17/25",
    "1/18/25",
    "1/19/25",
    "1/20/25",
    "1/21/25",
    "1/22/25",
    "1/23/25",
    "1/24/25",
    "1/25/25",
    "1/26/25",
    "1/27/25",
    "1/28/25",
    "1/29/25",
    "1/30/25",
    "1/31/25",
    "2/1/25",
    "2/2/25",
    "2/3/25",
    "2/4/25",
    "2/5/25",
    "2/6/25",
    "2/7/25",
    "2/8/25",
    "2/9/25",
    "2/10/25",
    "2/11/25",
    "2/12/25",
    "2/13/25",
    "2/14/25",
    "2/15/25",
    "2/16/25",
    "2/17/25",
    "2/18/25",
    "2/19/25",
    "2/20/25",
    "2/21/25",
    "2/22/25",
    "2/23/25",
    "2/24/25",
    "2/25/25",
    "2/26/25",
    "2/27/25",
    "2/28/25",
    "3/1/25",
    "3/2/25",
    "3/3/25",
  ];


  // Align the first two value axes to the left
  // and the last two to the right.
  //
  // Right alignment is done by specifying a
  // crossing value greater than or equal to
  // the number of categories.
  public crossingValues: number[] = [0, 9999999999999];
  public maxTempThreshold = new Array(this.categories.length).fill(60);


  // Events Chart
     public chargeData = [
      {
      current: 'Power Restore Log Entry',
      stats: [
        { time: new Date('2025-1-12'), amount: 0 },
        { time: new Date('2025-1-13'), amount: 1 },
        { time: new Date('2025-1-14'), amount: 5 },
        { time: new Date('2025-1-15'), amount: 1 },
        { time: new Date('2025-1-16'), amount: 3 },
        { time: new Date('2025-1-17'), amount: 2 },
        { time: new Date('2025-1-18'), amount: 4 },
        { time: new Date('2025-1-19'), amount: 2 },
        { time: new Date('2025-1-20'), amount: 2 },
        { time: new Date('2025-1-21'), amount: 0 },
      ]
    },
    {
      current: "Power Restore",
      stats: [
        { time: new Date('2025-1-12'), amount: 1 },
        { time: new Date('2025-1-13'), amount: 2 },
        { time: new Date('2025-1-14'), amount: 4 },
        { time: new Date('2025-1-15'), amount: 5 },
        { time: new Date('2025-1-16'), amount: 3 },
        { time: new Date('2025-1-17'), amount: 1},
        { time: new Date('2025-1-18'), amount: 1 },
        { time: new Date('2025-1-19'), amount: 2 },
        { time: new Date('2025-1-20'), amount: 0 },
        { time: new Date('2025-1-21'), amount: 0 },
      ],
    },
    {
      current: 'Momentary PWR Disruption',
      stats: [
        { time: new Date('2025-1-12'), amount: 1 },
        { time: new Date('2025-1-13'), amount: 0 },
        { time: new Date('2025-1-14'), amount: 5 },
        { time: new Date('2025-1-15'), amount: 4 },
        { time: new Date('2025-1-16'), amount: 5 },
        { time: new Date('2025-1-17'), amount: 3 },
        { time: new Date('2025-1-18'), amount: 0 },
        { time: new Date('2025-1-19'), amount: 0 },
        { time: new Date('2025-1-20'), amount: 0 },
        { time: new Date('2025-1-21'), amount: 2 },
      ],
    },
    {
      current: 'Power Down Soft Reboot',
      stats: [
        { time: new Date('2025-1-12'), amount: 0 },
        { time: new Date('2025-1-13'), amount: 1 },
        { time: new Date('2025-1-14'), amount: 3 },
        { time: new Date('2025-1-15'), amount: 4 },
        { time: new Date('2025-1-16'), amount: 2 },
        { time: new Date('2025-1-17'), amount: 4 },
        { time: new Date('2025-1-18'), amount: 5 },
        { time: new Date('2025-1-19'), amount: 7 },
        { time: new Date('2025-1-20'), amount: 5 },
        { time: new Date('2025-1-21'), amount: 5 },
      ],
    },
    {
      current: 'Power Down',
      stats: [
        { time: new Date('2025-1-12'), amount: 4 },
        { time: new Date('2025-1-13'), amount: 0 },
        { time: new Date('2025-1-14'), amount: 5 },
        { time: new Date('2025-1-15'), amount: 0 },
        { time: new Date('2025-1-16'), amount: 4 },
        { time: new Date('2025-1-17'), amount: 1 },
        { time: new Date('2025-1-18'), amount: 6 },
        { time: new Date('2025-1-19'), amount: 2 },
        { time: new Date('2025-1-20'), amount: 1 },
        { time: new Date('2025-1-21'), amount: 0 }
      ],
    },
    {
      current: 'Power Down Cause Unknown',
      stats: [
        { time: new Date('2025-1-12'), amount: 2 },
        { time: new Date('2025-1-13'), amount: 3 },
        { time: new Date('2025-1-14'), amount: 0 },
        { time: new Date('2025-1-15'), amount: 4 },
        { time: new Date('2025-1-16'), amount: 5 },
        { time: new Date('2025-1-17'), amount: 2 },
        { time: new Date('2025-1-18'), amount: 0 },
        { time: new Date('2025-1-19'), amount: 0 },
        { time: new Date('2025-1-20'), amount: 0 },
        { time: new Date('2025-1-21'), amount: 1 }
      ],
    },
  ];

// Labels for the right-hand axis
//   public eventNames = [
//     "System Initialized",
//     "Power Restore Log Entry",
//     "Power Restore",
//     "Momentary Pwr Disruption",
//     "Power Down Soft Reboot",
//     "Power Down Cause Unknown"
//   ];


//   public eventChartData = [
//     { x: new Date('2025-6-1'), yValue: 0, yIdx: 0 },
//     { x: new Date('2025-6-2'), yValue: 3, yIdx: 1 },
//     { x: new Date('2025-6-2'), yValue: 3, yIdx: 1 },
//     { x: new Date('2025-6-3'), yValue: 4, yIdx: 2 },
//     { x: new Date('2025-6-4'), yValue: 5, yIdx: 3 },
//     { x: new Date('2025-6-5'), yValue: 2, yIdx: 4 }
//   ];

  // Logic to put the 2nd axis on the far right of the date range
//   public axisCrossingValue = [0, new Date(2099, 11, 31)];

//   public rightAxisLabels = (args: AxisLabelContentArgs): string => {
//     return this.eventNames[args.value] || "";
//   };
}

interface TimeBasis {
    id?: number | null;
    time: string;
}

interface UnitMeasurement {
    id?: number | null;
    unit: string;
}

interface TimeIncrement {
    id: number;
    name: string;
}

interface FactCategory {
    id?: number | null;
    category: string;
}

// interface EventCategory {
//     id?: number | null;
//     category: string;
// }

interface NicTimeBasis {
    id?: number | null;
    time: string;
}

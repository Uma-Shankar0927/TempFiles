import { FusionRoutes } from '@fusion/ngx-fusion';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { ExplorerComponent } from './pages/explorer/explorer.component';
import { MeterDetailsComponent } from './pages/meter-details/meter-details.component';
import { TransformerDetailsComponent } from './pages/transformer-details/transformer-details.component';
import { CircuitDetailsComponent } from './pages/circuit-details/circuit-details.component';
import { MapDetailsComponent } from './pages/map-details/map-details.component';
import { AdminComponent } from './pages/admin/admin.component';

export const routes: FusionRoutes = {
    routes: [
        {
            path: 'admin',
            component: AdminComponent,
            menu: {
                icon: 'gear-fill',
                label: 'Admin',
                routerLink: 'admin'
            },
            showUser: false
        },
        {
            path: 'dashboard',
            component: DashboardComponent,
            menu: {
                icon: 'grid-fill',
                label: 'Dashboard',
                routerLink: 'dashboard'
            },
            showUser: false
        },
        {
            path: 'explorer',
            component: ExplorerComponent,
            menu: {
                icon: 'bar-chart-fill',
                label: 'Explorer',
                routerLink: 'explorer'
            },
            showUser: false
        },
        {
            path: 'meter-details/:meterId',
            component: MeterDetailsComponent
        },
        {
            path: 'transformer-details/:pointId',
            component: TransformerDetailsComponent
        },
        {
            path: 'circuit-details/:circuitId',
            component: CircuitDetailsComponent
        },
        {
            path: 'map-details',
            component: MapDetailsComponent
        },
        // This stays at the bottom
        {
            path: '**',
            redirectTo: 'dashboard'
        }
    ]
};

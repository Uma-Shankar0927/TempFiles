import { NgClass } from '@angular/common';
import { Component, effect, signal } from '@angular/core';
import { FusionButtonComponent, FusionDataGridBaseFilterCellComponent, FusionDropdownComponent } from '@fusion/ngx-fusion';
import { utilityTypeFilter, utilityTypeFilterProperty } from '../../tools';

@Component({
  selector: 'app-utility-type-filter-cell',
  imports: [
    FusionDropdownComponent,
    FusionButtonComponent,
    NgClass
],
  templateUrl: './utility-type-filter-cell.component.html',
  styleUrl: './utility-type-filter-cell.component.scss'
})
export class UtilityTypeFilterCellComponent extends FusionDataGridBaseFilterCellComponent {
    // TODO: should come from api / database call
  readonly options = signal([
    { name: 'electric', value: 0 },
    { name: 'gas', value: 1 },
    { name: 'solar', value: 2 },
    { name: 'electric and gas', value: 3 },
  ]);

  protected override valueEffect = effect(() => {
    const value = this.value() as { name: string; value: number } | null;

    if (!value) {
      this.filterService.filter({ filters: [], logic: 'and' });
      return;
    }

      // Build filter, if filterProperty is algorithm then we need to use 'contains' operator as the value is an array
              const filter = {
                  field: utilityTypeFilterProperty,
                  operator: utilityTypeFilter,
                  value: value.name.toLowerCase()
              };
      

// Apply the filter with 'or' logic to include any of the selected options
this.filterService.filter({ filters: [filter], logic: 'and' });
  });
}
import { NgClass } from '@angular/common';
import { Component, effect, signal } from '@angular/core';
import { FusionButtonComponent, FusionDataGridBaseFilterCellComponent, FusionDropdownComponent } from '@fusion/ngx-fusion';
import { transformerFilter, transformerFilterProperty } from '../../tools';

@Component({
  selector: 'app-transformer-status-filter-cell',
  imports: [
    FusionDropdownComponent,
    FusionButtonComponent,
    NgClass
],
  templateUrl: './transformer-status-filter-cell.component.html',
  styleUrl: './transformer-status-filter-cell.component.scss'
})
export class TransformerFilterCellComponent extends FusionDataGridBaseFilterCellComponent {
    // TODO: should come from api / database call
  readonly options = signal([
    { name: 'normal', value: 0 },
    { name: 'underloaded', value: 1 },
    { name: 'watchlist', value: 2 },
    { name: 'overloaded', value: 3 },
    { name: 'immediate', value: 4 }
  ]);

  protected override valueEffect = effect(() => {
    const value = this.value() as { name: string; value: number } | null;

    if (!value) {
      this.filterService.filter({ filters: [], logic: 'and' });
      return;
    }

      // Build filter, if filterProperty is algorithm then we need to use 'contains' operator as the value is an array
              const filter = {
                  field: transformerFilterProperty,
                  operator: transformerFilter,
                  value: value.name.toLowerCase()
              };
      

// Apply the filter with 'or' logic to include any of the selected options
this.filterService.filter({ filters: [filter], logic: 'and' });
  });
}
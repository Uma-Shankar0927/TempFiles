import { NgClass } from '@angular/common';
import { Component, effect, inject, signal } from '@angular/core';
import { FusionButtonComponent, FusionDataGridBaseFilterCellComponent, FusionDropdownComponent } from '@fusion/ngx-fusion';
import { algorithmFilter, algorithmFilterProperty } from '../../tools';
import { SecurityService } from '../../services/security/security.service';

@Component({
  selector: 'app-algorithm-filter-cell',
  imports: [
    FusionDropdownComponent,
    FusionButtonComponent,
    NgClass
],
  templateUrl: './algorithm-filter-cell.component.html',
  styleUrl: './algorithm-filter-cell.component.scss'
})
export class AlgorithmFilterCellComponent extends FusionDataGridBaseFilterCellComponent {
 readonly securityService = inject(SecurityService);

    // TODO: should come from api / database call
  readonly RevenueAssuranceOptions = signal([
    { name: 'All', value: 0 },
    { name: 'All Metering', value: 1 },
    { name: 'All Revenue Assurance', value: 2 },
    { name: 'All Customer Service', value: 3 },
    { name: 'Hot Socket', value: 4 },
    { name: 'Miscellaneous Voltage', value: 5 },
    { name: 'Double Voltage', value: 6 },
    { name: 'No Algorithms', value: 7 },
    { name: 'Frequent Outages', value: 8 },
    { name: 'Targeted No Meters', value: 9 },
    { name: 'Communicating with No Reads', value: 10 },
    { name: 'Zero Electricity Usage', value: 11 },
    { name: 'RP Removed Meters', value: 12 },
    { name: 'Reverse Energy', value: 13 }
  ]);
  readonly DistOpsOptions = signal([
    { name: 'Hot Socket', value: 1 },
    { name: 'Miscellaneous Voltage', value: 2 },
    { name: 'Double Voltage', value: 3 },
    { name: 'No Algorithms', value: 4 },
    { name: 'Frequent Outages', value: 5 },
    { name: 'Targeted No Meters', value: 6 },
    { name: 'Communicating with No Reads', value: 7 },
    { name: 'Zero Electricity Usage', value: 8 },
    { name: 'RP Removed Meters', value: 9 },
    { name: 'Reverse Energy', value: 10 }
  ]);

  protected override valueEffect = effect(() => {
    const value = this.value() as { name: string; value: number } | null;

    if (!value) {
      this.filterService.filter({ filters: [], logic: 'and' });
      return;
    }

      // Build filter, if filterProperty is algorithm then we need to use 'contains' operator as the value is an array
              const filter = {
                  field: algorithmFilterProperty,
                  operator: algorithmFilter,
                  value: value.name.toLowerCase()
              };
      

// Apply the filter with 'or' logic to include any of the selected options
this.filterService.filter({ filters: [filter], logic: 'and' });
  });
}
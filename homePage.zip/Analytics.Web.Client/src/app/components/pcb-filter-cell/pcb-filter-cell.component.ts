import { NgClass } from '@angular/common';
import { Component, effect, signal } from '@angular/core';
import { FusionButtonComponent, FusionDataGridBaseFilterCellComponent, FusionDropdownComponent } from '@fusion/ngx-fusion';
import { pcbFilter, pcbFilterProperty } from '../../tools';

@Component({
  selector: 'app-pcb-filter-cell',
  imports: [
    FusionDropdownComponent,
    FusionButtonComponent,
    NgClass
],
  templateUrl: './pcb-filter-cell.component.html',
  styleUrl: './pcb-filter-cell.component.scss'
})
export class PcbFilterCellComponent extends FusionDataGridBaseFilterCellComponent {
    // TODO: should come from api / database call
  readonly options = signal([
    { name: 'contains pcb', value: 0 },
    { name: 'contains pcb installed', value: 1 },
    { name: 'unknown', value: 2 },
    { name: 'unknown installed', value: 3 },
    { name: 'status unknown', value: 4 }
  ]);

  protected override valueEffect = effect(() => {
    const value = this.value() as { name: string; value: number } | null;

    if (!value) {
      this.filterService.filter({ filters: [], logic: 'and' });
      return;
    }

      // Build filter, if filterProperty is algorithm then we need to use 'contains' operator as the value is an array
              const filter = {
                  field: pcbFilterProperty,
                  operator: pcbFilter,
                  value: value.name.toLowerCase()
              };
      

// Apply the filter with 'or' logic to include any of the selected options
this.filterService.filter({ filters: [filter], logic: 'and' });
  });
}
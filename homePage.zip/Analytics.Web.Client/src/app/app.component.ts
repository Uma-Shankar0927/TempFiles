import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import {
    FUSION_DROPDOWN, FusionAppComponent, FusionContentComponent, FusionFooterComponent,
    FusionHeaderComponent, FusionPageBaseComponent
} from '@fusion/ngx-fusion';
import { SecurityService } from './services/security/security.service';

@Component({
    imports: [
        FormsModule,
        FusionAppComponent,
        FusionFooterComponent,
        FusionHeaderComponent,
        FusionContentComponent,
        FUSION_DROPDOWN
    ],
    selector: 'app-root',
    standalone: true,
    styleUrls: ['./app.component.scss'],
    templateUrl: './app.component.html'
})
export class AppComponent extends FusionPageBaseComponent {
    private readonly _securityService = inject(SecurityService);

    options: Role[] = [
        { id: 1, name: 'Distribution Ops' },
        { id: 2, name: 'Revenue Assurance' }
    ];
    value = this.options[0];

    onRoleChange(role: Role) {
        this._securityService.setRoleId(role.id);
    }
}

interface Role {
    id: number;
    name: string;
}

import { FusionConfig } from '@fusion/ngx-fusion';

export const fusionConfigBase: FusionConfig = {
    api: {
        baseUrl: ''
    },
    isDebug: true,
    nativeApp: {
        statusBar: {
            show: true
        }
    },
    theme: 'system'
};
